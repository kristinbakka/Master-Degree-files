m = 20; %number of different theta values
n = 30; %number of different r values
P0=5;

theta = linspace(0,2*pi,m+1);
%%Include this to avoid two representations of same point (0 and 2*pi)
%theta = theta(1:m);

%make a grid
r = linspace(0.1,5,n);
[R,T] = meshgrid(r,theta);
%function of grid
z = P0./R;

%translate grid for plotting
x = R.*cos(T);
y = R.*sin(T);

surf(x,y,z);
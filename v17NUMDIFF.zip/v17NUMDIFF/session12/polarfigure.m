r0=0.2;
r1=1;

%----------

%theta=(0):(2*pi);
theta_1=linspace(0,2*pi,100);
rho=linspace(r0,r1,length(theta_1));

theta_2=linspace(0,2*pi,13);
hold off;

%fix colors:
f = figure;
%inner circle
polar(theta_1,r0.*ones(1,length(theta_1)),'b');
%rlim([0,r1])
ax = findall(f.Children, 'Type', 'Axes');
labels = findall(ax, 'Type', 'Text', 'HorizontalAlignment', 'left');
% Hide all the R-axis labels.
[labels.Visible] = deal('off');
polarplot(theta_1,r0.*ones(1,length(theta_1)),'b');


%thetaticks(0:pi/4:3*pi/4)
pax = gca;
pax.ThetaAxisUnits = 'radians';
hold on;
%outer circle
polarplot(theta_1, ones(1,length(theta_1)),'b')

%polarplot(theta_1,r1.*ones(1,length(theta_1)));

%points
theta_2rep=repmat(theta_2,1,3);
l=length(theta_2);
a=[0.4 0.6 0.8];
polarplot(theta_2rep,[a(1)*ones(1,l) a(2)*ones(1,l) a(3)*ones(1,l)],'r*')
%inner circle
set(gca, 'ColorOrder', [0 0.3 0.3]);
polarplot(theta_2,0.2.*ones(1,l),'*')
%outer circle
set(gca, 'ColorOrder', [0 0.3 0.3]);
polarplot(theta_2, ones(1,l),'*')


theta_2rep=repmat(theta_2,4,1);

set(gca, 'ColorOrder', [0.5 0 0.5]);
polarplot([0 0 0 0 0], [0.2 0.4 0.6 0.8 1],'*')

set(gca, 'ColorOrder', [0.8 0 0.8]);
polarplot(pi/6*ones(3,1), [0.4 0.6 0.8],'*')



% Taken from 'doc polar' example:
% http://www.mathworks.com/help/matlab/ref/polar.html
theta = 0:0.01:2*pi;
rho = sin(2*theta).*cos(2*theta);
f = figure;
polar(theta,rho,'--r');
% Extract all of the 'Text' objects from the polar plot.
ax = findall(f.Children, 'Type', 'Axes');
% Filter the 'Text' objects by the 'HorizontalAlignment' property.
% PLEASE NOTE: This may not generalize to other versions of MATLAB
% where the default 'HorizontalAlignment' value for R-axis labels is not
% set to 'left'.
labels = findall(ax, 'Type', 'Text', 'HorizontalAlignment', 'left');
% Hide all the R-axis labels.
[labels.Visible] = deal('off');
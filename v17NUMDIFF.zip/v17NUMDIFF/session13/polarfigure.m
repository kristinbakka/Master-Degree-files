r0=0.2;
r1=1;

%----------

%theta=(0):(2*pi);
theta_1=linspace(0,2*pi,100);
rho=linspace(r0,r1,length(theta_1));

theta_2=linspace(0,2*pi,13);
hold off;

%fix colors:

%inner circle
%ax = polaraxes;
polarplot(theta_1,r0.*ones(1,length(theta_1)),'b');
rlim([0,r1])
ax = gca;
ax.RTickLabel = {'','r=r_1','','','','r=r_{n}'};
ax.ThetaTickLabel = {'\theta_1=0','\theta_2=\pi/6','\theta_3=\pi/3','\theta_4=\pi/2','\theta_5=2\pi/3','\theta_6=5\pi/6','\theta_7=\pi','\theta_8=7\pi/6','\theta_9=4\pi/3','\theta_{10}=3\pi/2','\theta_{m-1}=5\pi/3','\theta_{m}=\pi/6'};
%ax.RAxisLocation = 90;
ax.FontSize=14;

%ax.FontSize=16;
%thetaticks(0:pi/4:3*pi/4)
pax = gca;
pax.ThetaAxisUnits = 'radians';
hold on;
%outer circle
polarplot(theta_1, ones(1,length(theta_1)),'b')

%polarplot(theta_1,r1.*ones(1,length(theta_1)));

%points
theta_2rep=repmat(theta_2,1,3);
l=length(theta_2);
a=[0.4 0.6 0.8];
polarplot(theta_2rep,[a(1)*ones(1,l) a(2)*ones(1,l) a(3)*ones(1,l)],'r*')

theta_2rep=repmat(theta_2,4,1);

set(gca, 'ColorOrder', [0.8 0 0.8]);
polarplot([0 0 0 0 0], [0.2 0.4 0.6 0.8 1],'*')

%set(gca, 'ColorOrder', [1 140/255 0]);
%polarplot(pi/6*ones(5,1), [0.2 0.4 0.6 0.8 1],'*')

%inner circle
set(gca, 'ColorOrder', [0 0.3 0.3]);
polarplot(theta_2,0.2.*ones(1,l),'s')
%outer circle
set(gca, 'ColorOrder', [0 0.3 0.3]);
polarplot(theta_2, ones(1,l),'s')



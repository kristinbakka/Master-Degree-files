clear
%ex2
%entities
a=-1;
%g= @(x,t) (exp(-x.^2)*exp(-0.5*t(1).^2));
g= @(x) (exp(-x.^2));
analytic = @(x,t) (exp(-x.^2).*exp(-a.^2.*t.^2)).*exp(2.*a.*t.*x);
%x from 0 to 1
xend=-5;
xstart=5;
%CHECK xend=xstart :D
%Decide on steps in x-direction
M=300;%M is small, h is large, r is small
Mrl= (M-1)/2;
h=(xend-xstart)/(M-1);
x=(xstart:h:xend)';
%Decide on to-time and stepsize k in time
T=1;
N=7000; %N is large, k is small, r is small
k=T/N; 
t=0:k:T;
%Construct solution matrix and Vvec
approx=zeros(N+1,M); %N is #estimated timesteps
Uvec=g(x);
%Uvec(end)=0;
%Uvec(1)=0;
approx(1,:)=Uvec;
%Construct B's
B10=spdiags([-ones(M,1),ones(M,1)], [0,1],M,M);
B11=spdiags([-ones(M,1),ones(M,1)], [-1,0],M,M);
B12=spdiags([-ones(M,1),ones(M,1)], [-1,1],M,M);
%analytic solution
solution = approx;
for i=2:N+1
     plot(Uvec);
     Uvec=Uvec-a*k/h*(B12*Uvec); %next=prev+k*F(prev)
     approx(i,:)=Uvec; 
     Svec=analytic(x,t(i));
     solution(i,:)=Svec;
end
%surf(approx);
%xlabel('x');
%ylabel('t');

%2 norm error of last time value
e2 = norm(Uvec-Svec,2)*sqrt(h);

plot(x, Uvec-Svec);
%feilsøking
r=k/h^2;
testB10=full(B10);
testB11=full(B11);
testB12=full(B12);

%plot(x,Vvec);
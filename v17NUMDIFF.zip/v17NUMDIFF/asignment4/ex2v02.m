clear
%ex2
%entities
a=-1;
g= @(x) cos(2*pi*x);
%x from 0 to 1
xend=1;
xstart=0;
%CHECK xend=xstart :D
%Decide on steps in x-direction
M=5;%M is small, h is large, r is small
h=(xend-xstart)/M;
x=((xstart):h:(xend-h))';
%Decide on to-time and stepsize k in time
T=1;
N=20; %N is large, k is small, r is small
k=T/N; 
%Construct solution matrix and Vvec
approx=zeros(N+1,M); %N is #estimated timesteps
Uvec=g(x);
approx(1,2:M+1)=Uvec;
%Construct B's
B10=spdiags([-ones(M,1),ones(M,1)], [0,1],M,M);
B10(end,1)=1;

B11=spdiags([-ones(M,1),ones(M,1)], [-1,0],M,M);
B11(1,end)=-1;

B12=spdiags([-ones(M,1),ones(M,1)], [-1,1],M,M);
B12(end,1)=1;
B12(1,end)=-1;


for i=2:N+1
     plot(Uvec);
     Uvec=Uvec-a*k/h*(B10*Uvec); %next=prev+k*F(prev)
     approx(i,2:M+1)=Uvec; 
end
surf(approx);
xlabel('x');
ylabel('t');
%axis([-1 1 0 T])
%set(gca, 'XTick',0.20:0.05:0.80)
%set(gca, 'YTick',0.20:0.05:0.80)


%feilsøking
r=k/h^2;
testB10=full(B10);
testB11=full(B11);
testB12=full(B12);

%plot(x,Vvec);
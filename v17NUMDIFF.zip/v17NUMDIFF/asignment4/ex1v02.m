clear
%entities
a=0.01; %0.1, 0.01, 0.001
%a=0;
b=-1;
%b=0;
%Decide on to-time and stepsize k in time
T=1;
N=100000; % number of time steps
k=T/N; 
%Decide on steps in x-direction
%x from -1 to 1
M=200;%M is small, h is large, r is small
h=2/(1+M);
x=((-1+h):h:(1-h))';
%Construct solution matrix and Vvec
approx=zeros(N+1,M+2);
Vvec=cos(pi*x/2);
approx(1,2:M+1)=Vvec;
%Construct A
Aa=spdiags([ones(M,1),-2*ones(M,1),ones(M,1)], [-1,0,1],M,M)/h^2;
Ab=spdiags([-ones(M,1),ones(M,1)], [-1,1],M,M)/(2*h);

%construct f
f=ones(M,1);

for i=2:N+1
     Vvec=Vvec+k*(a*Aa*Vvec+b*Ab*Vvec+f); %next=prev+k*F(prev)
     approx(i,2:M+1)=Vvec;
end
     surf(approx);
xlabel('x');
ylabel('t');
%axis([-1 1 0 T])
%set(gca, 'XTick',0.20:0.05:0.80)
%set(gca, 'YTick',0.20:0.05:0.80)


%feilsøking
r=k/h^2;
Ba=full(Aa)*h*h;
Bb=full(Ab)*2*h;
%plot(x,Vvec);
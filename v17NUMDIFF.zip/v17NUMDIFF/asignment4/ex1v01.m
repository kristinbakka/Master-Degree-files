clear
%entities
a=0.1;
b=-1;
%Decide on to-time and stepsize k in time
T=1;
N=7; % number of time steps
k=T/N; 
%Decide on steps in x-direction
%x from -1 to 1
M=10;
h=2/(1+M);
x=((-1+h):h:(1-h))';
%Construct solution matrix and Vvec
approx=zeros(N+1,M+2);
Vvec=cos(pi*x/2);
approx(1,2:M+1)=Vvec;
%Construct A
t1=(a+h*b/2)*ones(M,1)/h^2; %NB: b is negative in this example
diag=-ones(M,1)/h^2;
b1=(a-h*b/2)*ones(M,1)/h^2;
A=spdiags([b1,diag,t1], [-1,0,1],M,M);

%construct f
f=ones(M,1);

plot(x,Vvec);

for i=2:N+1
     Vvec=Vvec+k*(A*Vvec+f); %next=prev+k*F(prev)
     approx(i,2:M+1)=Vvec;
     
     surf(approx);
xlabel('x');
ylabel('t');
%axis([-1 1 0 T])
set(gca, 'XTick',0.20:0.05:0.80)
set(gca, 'YTick',0.20:0.05:0.80)
end

     surf(approx);
xlabel('x');
ylabel('t');
%axis([-1 1 0 T])
set(gca, 'XTick',0.20:0.05:0.80)
set(gca, 'YTick',0.20:0.05:0.80)

function [ e2 ] = leapfrog( M,T,a)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%ex2 task 1
%entities
g= @(x) (exp(-x.^2));
analytic = @(x,t) (exp(-x.^2).*exp(-a.^2.*t.^2)).*exp(2.*a.*t.*x);
%x from 0 to 1
xend=5;
xstart=-5;
%Decide on steps in x-direction
%M=301;%M is small, h is large, r is small
h=(xend-xstart)/(M-1);
x=(xstart:h:xend)';
%Decide on to-time and stepsize k in time
%T=1;
N=7000; %N is large, k is small, r is small
k=T/N; 
t=0:k:T;
%Construct solution matrix and Vvec
Um2=g(x);
%Construct B's
B=spdiags([-ones(M,1),ones(M,1)], [-1,1],M,M);
Um1=Um2-a*p*(B*Um2)/2 +(a*p)^2*(B*Um2)/(4*h); %2nd value by Lax-Wendroff
for i=3:N+1
    U0=Um2 - a*p*(B*Um1);
    Um2=Um1;
    Um1=U0;
end
Svec=analytic(x,T);

e2 = norm(U0-Svec,2)*sqrt(h);
end


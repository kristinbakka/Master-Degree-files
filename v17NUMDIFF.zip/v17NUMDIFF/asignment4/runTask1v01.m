clear
fromM=20;
toM=70;
mvec=(fromM:1:toM)';
l=length(mvec);
e2Vec=zeros(l,1);
T=1;
a=5;
for i = 1:1:l
    %e2Vec(i)=task1(10,mvec(i),T,a); %order h^(1/2), should be order h?
    e2Vec(i)=task1(11,mvec(i),T,a); %order h^2. should diverge
    %e2Vec(i)=task1(12,mvec(i),T,a); %h^2 like it should
end

hvec=10./(mvec-1);


% %plot(mvec,e2Vec,mvec,0.4.*hvec);
% loglog(hvec,e2Vec,hvec,hvec.^2, hvec,sqrt(hvec));
% legend('error', 'h^2', 'h^{1/2}')

loglog(hvec,e2Vec,hvec,hvec.^2, hvec,hvec);
legend('error', 'h^2', 'h')

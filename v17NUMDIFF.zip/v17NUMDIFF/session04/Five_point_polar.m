function [R,T,retU]= Five_point_polar(m,n,r,theta,ny,f)
%define function at rand



%%(1) Generate representations of values of k and h
%Only for internal ("meaty") part:
N=n-2;
[R_m,T_m] = meshgrid(r(2:(n-1)),theta);
%k and h
k_top = r(3:end)-r(2:(end-1));
k_bottom = r(2:(end-1))-r(1:(end-2));
h = 2.*pi.*r(2:(end-1))./m;

%as meshgrids
K_top = repmat(k_top,m,1); %same for every theta
K_bottom = repmat(k_bottom,m,1); %same for every theta
K = ((K_top+K_bottom)./2);%expression derived from imagination, not mathematics: 
%                 (discretize again properly to check what it should be)
H = repmat(h,m,1); %same for every theta

%%(2) Calculate coefficient left/right over/under interior node
center = (-2.*(K.^(-2)+ (H.*R_m).^(-2)) + ny.^2);
right = (H.*R_m).^(-2);
left = right;
top = K.^(-2)+(2.*K.*R_m).^(-1); 
bottom = K.^(-2)-(2.*K.*R_m).^(-1);


%%(3)---Make A-------------------
%%(3.1) Interior of domain ('meaty part')
%center:
v0= [zeros(m,1);center(:);zeros(m,1)];
%top:
vt=[zeros(2*m,1);top(:)];
%bottom:
vb=[bottom(:);zeros(2*m,1)];

%right:
%v1 = [zeros(1,N);right(1:(m-1),:)](:);
temp=[zeros(1,N);right(1:(m-1),:)];
v1= [zeros(m,1);temp(:);zeros(m,1)];
%left:
%vm1= [left(2:m,:);zeros(1,N)](:);
temp=[left(2:m,:);zeros(1,N)];
vm1= [zeros(m,1);temp(:);zeros(m,1)];

%%(3.2) Construct A
A = spdiags([vb,vm1, v0, v1,vt], [-m,-1:1,m],m*n,m*n);

%%(3.3) FIX over flow points on right/left of interior nodes
%helping iterator
iteratorN=(1:(n-2));
%right:
A(sub2ind(size(A),(iteratorN+1).*m,iteratorN.*m+1))=right(m,:);
%left:
A(sub2ind(size(A),iteratorN.*m+1,(iteratorN+1).*m))=left(1,:);

%%(3.4) Fill in expressions for inner and outer boundary
inner_boundary = spdiags(m,2*m);
%outer_boundary = spdiags(m,2*m);
k_b = r(end)-r(end-1);
b_n = 1./k_b-1i*ny+1/(2*r(end));
b_n_m1 =-1./k_b.*ones(m);
outer_boundary = [spdiags(b_n_m1, 0,m,2*m) spdiags(b_n, 0,m,2*m)];

%%(3.5) Insert expressions of inner and outer boundary in A
A(1:m,1:(2*m)) = inner_boundary;
A(m*n - m + 1:m,m*n - 2*m + 1:(2*m))=outer_boundary;
%-------finished making A-----

%(4)---Make G--------------------
%%(4.1) Allocate and make iterator
G=sparse(m*n,1);
%index helper
iteratorM=1:m;

%%(4.2) Fill in inner boundary
%%Neumann:
% inner boundary circle %(= 0th circle)
 G(iteratorM)= zeros(m,1);
% 1st circle
    %I don't think you need 1st circle, but it is fun to play with ^^
 %G(i+m)= ones(m,1); %or try with other fun stuff :D
 G(iteratorM+m)= exp(1i.*ny.*theta); %or try with other fun stuff :D
 
%%(4.3) Fill in outer boundary
%%Mayda-Enquist:
% outer boundary circle %(= (N+1)th circle)
 G(m*n - m + iteratorM)= f(r(end),theta);
% Nth circle
 %G(m*n - 2*m + i)= ones(m,1)*0.01;
 %G(m*n - 2*m + iteratorM)= cos(theta.*4);
%-------finished making G-----

%(5)---Shorten G and A-----------
    %(so the code can run before BC's are complete)
%Remove biggest radius as long as Mayda-Enquist is not ready, 
    %or if M-E doesn't need it
% G=G(1:(end-m));
% A=A(1:(end-m),1:(end-m));
 
%Remove first radius as long as Neumann inner is not ready
 G=G((m+1):end);
 A=A((m+1):end,(m+1):end);
%---finished shortening G-----

%%(6) solve
U=A\(-G);

%%(7) Present solution in readable way
%return a matrix, not a vector
%as the code is now (March 9th)
retU = reshape(U, m, n-1);
%if one more row is added
%retU = reshape(U, m, n-1);
%if two more rows are added
%retU = reshape(U, m, n);

%%(8)Present (R,Theta) coordinate of each point

%plotter av bare interior points
%R=R_m;
%T=T_m;
%%for � plotte innerst ogs�, skriv i steden:
%%[R,T] = meshgrid(r(1:(n-1)),theta);
%for � plotte ytterst ogs�, skriv i steden:
[R,T] = meshgrid(r(2:(n)),theta);

if(size(R)~=size(retU))
    display('Size of R and retU dont mach up. They should! :D')
end
if(size(T)~=size(retU))
    display('Size of T and retU dont mach up. They should! :D')
end

end

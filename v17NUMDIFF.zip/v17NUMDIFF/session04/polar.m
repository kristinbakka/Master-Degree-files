clear
m = 100; %number of different theta values
n = 50; %number of different r values
N = n-2;

r0= 0.5;
r1= 5;
rc=0;

P0=5;
ny=0.2;
f = @(rho,the) P0.*exp(i.*ny.*(rho-rc)).*((rho-rc).^(-2)-(2*rho*(r-rc));


%values of radius and angle (theta)
theta = linspace(0,2*pi,m+1);
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points
r = linspace(r0,5,n); % n points

%call function to get solution
[R,T,S] = Five_point_polar(m,n,r,theta,ny,f);

%oversett til kartesiske koordinater
x = R.*cos(T);
y = R.*sin(T);
%legg p� theta=2*pi, slik at det blir komplett grid
plotx = [x;R(1,:).*cos(2*pi)];
ploty = [y;R(1,:).*sin(2*pi)];
plotU = [S;S(1,:)];
%plott
surf(plotx,ploty,real(plotU));
%surf(plotx,ploty,imag(plotU));
xlabel('x','FontSize',14)
ylabel('y','FontSize',14)
zlabel('Solution','FontSize',14)
title('Numerical Solution','FontSize',16)

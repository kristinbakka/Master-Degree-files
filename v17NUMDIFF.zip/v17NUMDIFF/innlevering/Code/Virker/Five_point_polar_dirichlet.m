function [R,T,retU]= Five_point_polar_dirichlet(m,n,r,theta,ny,P0)   
%Solves five point formula on annulus. Inner and outer circle are boundary
%conditions for plane wave.

%%(1) Generate representations of values of k and h
%Only for internal ("meaty") part:

[R,T] = meshgrid(r,theta);
%steplengths
dr=r(2)-r(1);
dT = (2.*pi./m);

%%(2) Calculate coefficient left/right over/under interior node 
center = (-2.*(dr.^(-2)+ dT^(-2)*R.^(-2)) + ny.^2);
side = dT^(-2)*R.^(-2);
top = dr.^(-2)+(2.*dr.*R).^(-1); 
bottom = dr.^(-2)-(2.*dr.*R).^(-1);

%%(3)---Make A-------------------
%%(3.1) Interior of domain ('meaty part')
%Here this is the whole matrix

%center:
%v0= [zeros(m,1);center(:);zeros(m,1)];
%top:
vt=[zeros(m,1),top(:,1:end-1)];
%bottom:
vb=[bottom(:,2:end),zeros(m,1)];
%right:
tempr=[zeros(1,n);side(1:(m-1),:)];
%v1= [zeros(m,1);tempr(:);zeros(m,1)];
%left:
templ=[side(2:m,:);zeros(1,n)];
%vm1= [zeros(m,1);templ(:);zeros(m,1)];

%%(3.2) Construct A
A = spdiags([vb(:),templ(:), center(:), tempr(:),vt(:)], [-m,-1:1,m],m*n,m*n);



%(3.3) FIX over flow points on right/left of interior nodes
%helping iterator
iteratorN=(1:n);
%right:
A(sub2ind(size(A),iteratorN.*m, (iteratorN-1).*m+1))=side(m,:);
%left:
A(sub2ind(size(A),(iteratorN-1).*m+1,(iteratorN).*m))=side(1,:);

% 
% %%(3.4) Fill in expressions for inner and outer boundary


%-------finished making A-----

%(4)---Make G--------------------
% AU + G = 0
%%(4.1) Allocate and make iterator
G=sparse(m*n,1);
%index helper
iteratorM=1:m;

%%(4.2) Fill in inner boundary
%%Neumann:
% inner boundary circle %(= 0th circle)
 G(iteratorM)= (dr.^(-2)-(2.*dr.*r(1)).^(-1))*P0.*exp(1i.*ny.*(r(1)-dr).*cos(theta)); %Bottom
 
%%(4.3) Fill in outer boundary
 G(m*n -m + iteratorM)= (dr.^(-2)+(2.*dr.*r(end)).^(-1))*P0.*exp(1i.*ny.*(r(end)+dr).*cos(theta)); %Top

%-------finished making G-----

%%(6) solve
U=A\(-G);

retU = reshape(U, m, n);

%%(7)Present (R,Theta) coordinate of each point

[R,T] = meshgrid(r,theta);

end
Hello, welcome to the readme of our Helmholtz project in Numdiff spring 2017.
These files were made and run using matlab 2014a and matlab 2016a.

To draw one of the plots from the project, simply run one of the files named run_*. NB: some of them are a little slow, so you might want to use a coarser grid. In that case please set N and/or M to lower values.

The files included are:
Functions:
F1 Five_point_polar
F2 Five_point_polar_2
F3 Five_point_square
F4 Five_point_polar_dirichlet

Helper functions:
H1 BJderZ
H2 BYderZ
H3 HderZ

Script on solution of Helmholtz with dirichlet boundary conditions:
D1 run_square_errors
D2 run_polar_d_errors

Scripts on scattering on annulus:
S1 run_polar_s_01_plots
S2 run_polar_s_error_r
S3 run_polar_s_error_theta

F1 and F2 implement scattering with respectively the 1st and 2nd order Majda Engquist operators.
S1 plots the numerical solution (or optionally the analytical one) when there is scattering, while S2 and S3 plot the errors when increasing number of grid points. S2 increase number of radi considered, and S3 increase number of angles considered.

F3 and F4 implement helmholtz plain wave solution when only values at boundaries are supplied on respectively a square and a polar domain.
D1 and D2 respectively plot the errors from F3 and F4.

The helper functions are there to simplify the code for the analytical solution of scattering on annulus.

Thank you for reading this. Please enjoy the plots. :)





%This file creates the numerical plots of the scatter wave on the annulus
%optionally also the analytical total wave (see line 99).

clear;
close all;

%% Initialization and preallocation

r0 = 3; % Radius of object(inner circle)
r1= 12; % Radius of domain

P0 = 1; % Amplitude
ny = (2/3)*pi; % Wave number k (ny is used throughout the code)
% m = number of different theta values
% n = number of different r values

%% Find error in theta direction while r is fixed, 1st order ME
m = 600; %number of different theta values: n
n = 600;            %number of different r values: m

% Values of radius and angle (theta)
theta = linspace(0,2*pi,m+1); %T(:,1); % 
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points
r = linspace(r0,r1,n);% R(1,:); %  n points


%% Numerical solution
%Call function to get solution
%First order ME, second order discretization of Helmholtz:
[R,T,S] = Five_point_polar_2(m,n,r,theta,ny,P0);
% R = radius, T = theta, S = solution

%Second order ME, second order discretization of Helmholtz:
% [R,T,S] = Five_point_polar_2(m,n,r,theta,ny,P0);


%% Analytical solution, scatter wave P_s
% Analytic solution found on p. 30 in 
% Ihlenburg: Finite element analysis of acoustic scattering (1998)
sum = 0;
    % Sum in formula
    for it = 1:20
        sum = sum + (1i^it)*cos(it*T)*bJderZ(it,ny*r0).*besselh(it,ny*R)./(HderZ(it,ny*r0)); 
    end
    term1 = (1/2)*(1i^0)*cos(0*T)*bJderZ(0,ny*r0).*besselh(0,ny*R)./(HderZ(0,ny*r0));

    p_s = -2*P0*(term1 + sum); % Final wave
    
    

%% Translation to cartesian coordinates and plots

% Incoming wave, analytical solution
u_i = P0.*exp(1i.*ny.*R.*cos(T)); 

% Translate from polar to cartesian coordinates
x = R.*cos(T);
y = R.*sin(T);
% Add theta=2*pi to obtain a complete grid
plotx = [x;R(1,:).*cos(2*pi)];  % x-coord + gap row
ploty = [y;R(1,:).*sin(2*pi)];  % y-coord + gap row
plotUs = [S;S(1,:)];            % Numerical scatter wave
plotu_i= [u_i;u_i(1,:)];        % Incoming wave
plotUs_ref = [p_s;p_s(1,:)];    % Scatter wave for analytic solution


% Plots
    % Incoming wave
    figure()
    s_pi=surf(plotx,ploty,real(plotu_i));
    s_pi.EdgeColor = 'none';
    xlabel('x','FontSize',14)
    ylabel('y','FontSize',14)
    %zlabel('Solution','FontSize',14)
    title('Incoming wave','FontSize',15)

    
    % Scatter wave
    figure()
    s_ps=surf(plotx,ploty,real(plotUs));
    s_ps.EdgeColor = 'none';
    xlabel('x','FontSize',14)
    ylabel('y','FontSize',14)
    %zlabel('Solution','FontSize',14)
    title('Numerical solution of scatter wave ','FontSize',15)

    
    % Total wave: Incoming + scatter
    figure()
    s_ptot=surf(plotx,ploty,real(plotUs+plotu_i));
    s_ptot.EdgeColor = 'none';
    xlabel('x','FontSize',14)
    ylabel('y','FontSize',14)
    %zlabel('Solution','FontSize',14)
    title('Total wave','FontSize',15)

    
%     % Analytical total wave
%     s_p_ref = surf(plotx,ploty,real(plotUs_ref));
%     s_p_ref = surf(plotx,ploty,real(plotUs_ref+plotu_i));
%     s_p_ref.EdgeColor = 'none';
%     xlabel('x','FontSize',14)
%     ylabel('y','FontSize',14)
%     zlabel('Solution','FontSize',14)
%     title('Numerical Solution','FontSize',15)

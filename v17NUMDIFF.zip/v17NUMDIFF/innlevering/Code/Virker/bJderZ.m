function [ der ] = bJderZ( ny,Z )
%Helperfunction 01
der=(ny./Z).*besselj(ny,Z)-besselj(ny+1,Z);
end

% function [ der ] = bYderZ( ny,Z )
% %Helperfunction 02
% der=(ny./Z).*bessely(ny,Z)-bessely(ny+1,Z);
% end
% 
% function [ der ] = HderZ( ny,Z )
% %Helperfunction 03
% der=bJderZ( ny,Z )+1i*bYderZ( ny,Z );
% end

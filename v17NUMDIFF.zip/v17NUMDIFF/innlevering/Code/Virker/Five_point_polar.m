function [R,T,retU]= Five_point_polar(m,n,r,theta,ny,P0)   
%E1: First order Majda og Engquist boundary at maximal radius, object at
%minimal radius. R and T are matrices of the radiuses and theta values that
%correspond to the same slot in retU. retU is the approximated solution of
%the scattered wave.

%%(1) Generate representations of values of k and h
%Only for internal part:

N=n-2;
[R_m,T_m] = meshgrid(r(2:(n-1)),theta);
%steplengths
dr=r(2)-r(1);
dT = (2.*pi./m);

%%(2) Calculate coefficient left/right over/under interior node 
center = (-2.*(dr.^(-2)+ dT^(-2)*R_m.^(-2)) + ny.^2);
side = dT^(-2)*R_m.^(-2);
top = dr.^(-2)+(2.*dr.*R_m).^(-1); 
bottom = dr.^(-2)-(2.*dr.*R_m).^(-1);


%%(3)---Make A-------------------
%%(3.1) Interior of domain ('meaty part')

%center:
v0= [zeros(m,1);center(:);zeros(m,1)];
%top:
vt=[zeros(2*m,1);top(:)];
%bottom:
vb=[bottom(:);zeros(2*m,1)];
%right:
temp=[zeros(1,N);side(1:(m-1),:)];
v1= [zeros(m,1);temp(:);zeros(m,1)];
%left:
temp=[side(2:m,:);zeros(1,N)];
vm1= [zeros(m,1);temp(:);zeros(m,1)];

%%(3.2) Construct A
A = spdiags([vb,vm1, v0, v1,vt], [-m,-1:1,m],m*n,m*n);

%%(3.3) FIX over flow points on right/left of interior nodes
%helping iterator
iteratorN=(1:(n-2));
%right:
A(sub2ind(size(A),(iteratorN+1).*m,iteratorN.*m+1))=side(m,:);
%left:
A(sub2ind(size(A),iteratorN.*m+1,(iteratorN+1).*m))=side(1,:);

%%(3.4) Fill in expressions for inner and outer boundary
inner_boundary = sparse(m,2*m);

%helping constants
inner_1=(1/dr^2+1/(2*dr*r(1))); %helping constants
inner_2=(1/dr^2-1/(2*dr*r(1))); %helping constants

%Values for the matrix
inner_top=(1+inner_1/inner_2)/(2*dr); 
inner_side=1/(inner_2*2*dr*dT^2*r(1)^2);
inner_self=(-2/dr^2-2/(dT^2*r(1)^2)+ny^2)/(inner_2*2*dr);

%Insert in the matrix:
%the nodes on top
inner_boundary(:,(m+1):end)= spdiags(ones(m,1)*inner_top,0,m,m);
%the nodes themselves
inner_boundary(:,1:m)= spdiags([ones(m,1).*inner_side,ones(m,1).*inner_self,ones(m,1).*inner_side],[-1 0 1],m,m);
inner_boundary(1,m)=inner_side;
inner_boundary(end,1)=inner_side;


% Outer Boundary
outer_boundary = sparse(m,2*m);

outer_1=(1/dr^2+1/(2.*dr.*r(end))); %helping constants
outer_2=(1/dr^2-1/(2.*dr.*r(end))); %helping constants

outer_side= -1/(outer_1.*2.*dr.*dT.^2.*r(end).^2);

%the nodes below:
outer_bottom= (-1/(2.*dr)).*(1+outer_2/outer_1);
outer_boundary(:,1:m)= spdiags(outer_bottom.*ones(m,1),0,m,m);
%the nodes themselves:
vnode=((-1i.*ny + 1/(2*r(end)) + (-1/(2.*dr)).*(1/outer_1).*(-2./dr.^2 -2./(dT.*r(end)).^2 + ny^2)).*ones(m,1));

%Insert in the matrix:
outer_boundary(:,(m+1):(2*m)) = spdiags([outer_side.*ones(m,1),vnode ,outer_side.*ones(m,1)],[-1,0,1],m,m);
outer_boundary(1,end)= outer_side;%rightnode of the first node
outer_boundary(end,m+1)= outer_side; %leftnode of the last node


%%(3.5) Insert expressions of inner and outer boundary in A
A(1:m,1:(2*m)) = inner_boundary;
A((end-m+1):end,(end-2*m+1):end) = outer_boundary;

%-------finished making A-----

%(4)---Make G--------------------
% AU + G = 0
%%(4.1) Allocate and make iterator
G=sparse(m*n,1);
%index helper
iteratorM=1:m;

%%(4.2) Fill in inner boundary
%%Neumann:
% inner boundary circle %(= 0th circle)
 G(iteratorM)= P0.*1i.*ny.*cos(theta).*exp(1i.*ny.*r(1).*cos(theta)); 
 
%%(4.3) Fill in outer boundary
%This is just zero, so no need to do anything

%-------finished making G-----

%%(6) solve
U=A\(-G);

retU = reshape(U, m, n);

%%(7)Present (R,Theta) coordinate of each point

[R,T] = meshgrid(r,theta);

end

%This file draws the incoming and/or the outgoing wave when there is a
%circular object at the center, and infinite Mayda Engquist boundary at
%maximal radius, or optionally a plane wave on an open domain, only plotted
%on the anulus, and with values determined by Dirichlet boundary
%conditions.
%Optionally the first or second order Mayda Engquist operator can be
%utilized.

clear
m = 200; %number of different theta values
n = 200; %number of different r values
N = n-2;

r0= 1; %radius of inner object
r1= 5;

P0=1;
ny=(2/3)*pi; %Wave number


%values of radius and angle (theta)
theta = linspace(0,2*pi,m+1);
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points

r = linspace(r0,r1,n); % n points

%call function to get solution
%First order ME:
%[R,T,U_s] = Five_point_polar(m,n,r,theta,ny,P0);
%Second order ME:
%[R,T,U_s] = Five_point_polar_2(m,n,r,theta,ny,P0);
%Dirichlet:
[R,T,U_s] = Five_point_polar_dirichlet(m,n,r,theta,ny,P0);
%incoming wave
U_i = P0.*exp(1i.*ny.*R.*cos(T)); 

%Translate to cartesian coordinates for plotting
x = R.*cos(T);
y = R.*sin(T);
%Add the values for theta=2*pi, so the grid is complete and the plots look nice.
plotx = [x;R(1,:).*cos(2*pi)];
ploty = [y;R(1,:).*sin(2*pi)];
plotU_s = [U_s;U_s(1,:)];
plotU_i= [U_i;U_i(1,:)];

%%Plot
%Only the scattered/returned wave
%s_p=surf(plotx,ploty,real(plotU_s));

%Total solution for Mayda Engquist
s_p=surf(plotx,ploty,real(plotU_s+plotU_i));

%Only the incoming wave for Mayda Engquist
%s_p=surf(plotx,ploty,real(plotU_i));

s_p.EdgeColor = 'none';
%surf(plotx,ploty,imag(plotU));
xlabel('x','FontSize',14)
ylabel('y','FontSize',14)
zlabel('Solution','FontSize',14)
title('Numerical Solution','FontSize',16)

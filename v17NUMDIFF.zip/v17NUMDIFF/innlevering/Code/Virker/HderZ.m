function [ der ] = HderZ( ny,Z )
%Helperfunction 03
der=bJderZ( ny,Z )+1i*bYderZ( ny,Z );
end

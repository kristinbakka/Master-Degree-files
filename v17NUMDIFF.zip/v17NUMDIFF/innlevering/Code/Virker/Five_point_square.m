function [X,Y,U]= Five_point_Square(h,M,k,N,x0,y0,gx0,gx1,gy0,gy1,ny)   
%Solves five point formula on square. Boundary conditions give a plane
%wave.

%Make A
e  = ones(M*N,1);
v0 = (-2*(1/k^2+1/h^2)+ny.^2)*e;
vb = e/(k^2);
vm1= repmat([ones(M-1,1);0]*(1/h^2),N,1);
v1 = repmat([0;ones(M-1,1)]*(1/h^2),N,1);

A = spdiags([vb,vm1, v0, v1,vb], [-M,-1:1,M],M*N,M*N);

%The grid points:
t=1:M;
X=(x0+ t*h)';

j=1:N;
Y=(y0+j*k)';

%Make G
%Includes boundary conditions:
G=zeros(N*M,1);
% %i=1:
 G(M*(j-1)+1)=G(M*(j-1)+1)+(1/h^2)*gx0(Y(j));
% %i=M:
 G(M*(j-1)+M)=G(M*(j-1)+M)+(1/h^2)*gx1(Y(j));
% %j=1:
 G(t)=G(t)+(1/k^2)*gy0(X(t));
%j=N:
G(M*(N-1)+t)=G(M*(N-1)+t)+1/k^2*gy1(X(t));

%Find the unknown function values:
U=A\(-G);

end
%Helmholtz on a Square
%Plots errors in y and x directions on a square.
%To make it run faster/ with finer grid change lines 25 and 27.

%Problem specifications:
x0=0;
xend=1;
y0=0;
yend=1;
a=2*pi;
b=3*pi;
A0=1;
ny=sqrt(a^2+b^2);

%Dirichlet boundary conditions:
gx0= @(y) A0*exp(1i*(b*y+a*x0));
gx1=@(y) A0*exp(1i*(b*y+a*xend));
gy0= @(x) A0*exp(1i*(b*y0+a*x));
gy1= @(x) A0*exp(1i*(b*yend+a*x));

%Analytical solution:
u_exact =@(x,y) A0*exp(1i*(a*x+b*y));

%for numerical plotting:
M=200;
h=(xend-x0)/(M+1);
N=200;
k=(yend-y0)/(N+1);

%% Numerical solution

[X,Y,U]= Five_point_Square(h,M,k,N,x0,y0,gx0,gx1,gy0,gy1, ny);
Umat=zeros(N,M);
for j=1:N
    for t=1:M
        Umat(j,t)=U(M*(j-1)+t);
    end
end

figure(1)
surf(X,Y,imag(Umat))
xlabel('x','FontSize',14)
ylabel('y','FontSize',14)
zlabel('Solution','FontSize',14)
title('Numerical Solution','FontSize',16)

%Plotting analytical solution:

% Usol=zeros(length(Y),length(X));
% for t=1:length(X)
%     Usol(:,t)=u_exact(X(t),Y);
% end
% figure(2)
% surf(X,Y,imag(Usol))
% xlabel('x','FontSize',14)
% ylabel('y','FontSize',14)
% zlabel('Solution','FontSize',14)
% title('Analytical Solution','FontSize',16)

%% Error estimate

P=6;%Increase to measure for finer grid (that is, get several measurements)
Pref=P+5;%Increase this to have finer grid in the direction not measured.

%For reference:
href=1/(2^(Pref));
Mref=(xend-x0)/href -1;
kref=1/(2^(Pref));
Nref=(yend-y0)/kref -1;

%In x-direction:
x_error=zeros(1,P);
H=zeros(1,P);
for p=1:P
    faktor=p+2;
    H(p)=1/(2^faktor);
    Merror=(xend-x0)/H(p) -1;
    [X,Y,U]= Five_point_Square(H(p),Merror,kref,Nref,x0,y0,gx0,gx1,gy0,gy1,ny);
  
    
    abs_error=zeros(Merror,Nref);
    for t=1:Merror;
        for j=1:Nref
            abs_error(t,j)=U(Merror*(j-1)+t)-u_exact(X(t),Y(j));
        end
    end
 
    abs_error=imag(abs_error);
    %Funtion norm:
    x_error(p)=sqrt(H(p)*kref)*norm(abs_error,'fro');
    
end

%In y-direction:
y_error=zeros(1,P);
K=zeros(1,P);
for p=1:P
    faktor=p+2;
    K(p)=1/(2^faktor);
    Nerror=(yend-y0)/K(p) -1;
    [X,Y,U]= Five_point_Square(href,Mref,K(p),Nerror,x0,y0,gx0,gx1,gy0,gy1,ny);
    
    abs_error=zeros(Mref,Nerror);
    for t=1:Mref;
        for j=1:Nerror
             abs_error(t,j)=U(Mref*(j-1)+t)-u_exact(X(t),Y(j));
        end
    end
    abs_error=imag(abs_error);
    %Function norm:
    y_error(p)=sqrt(href*K(p))*norm(abs_error,'fro');
    
end

figure(3)
loglog(H,x_error,'bo-')
hold on;
loglog(K,y_error,'r*-')
loglog(H,H.^2,'k--')


legend('Error in x, 2-function norm',...
    'Error in y, 2-function norm','Reference line, slope 2')
title('Error','FontSize',16)
xlabel('Stepsize','FontSize',14)
ylabel('Error','FontSize',14)
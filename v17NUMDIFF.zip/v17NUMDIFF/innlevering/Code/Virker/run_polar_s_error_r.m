%This file plots the errors when changing number of radi in the grid
%when theta is fixed for first and second order Mayda Engquist operators.


clear;
close all;

%% Initialization and preallocation
p = 1;          % Counting variable

start = 3; %   % Start-n for number of different r values
inkr = 1;  %    % Increment for ...
slutt = 9;%   % End-n for ...

r0 = 1; % Radius of object(inner circle)
r1= 5; % Radius of domain

P0 = 1; % Amplitude
ny = (2/3)*pi; % Wave number k (ny is used throughout the code)

% Preallocation
delta_r = zeros(1,5); 
delta_theta = zeros(1,5);
norm_err = zeros(1,5);

% m = number of different theta values
% n = number of different r values

%% Find error in r direction while theta is fixed, 1st order ME
for n = 2.^(start:inkr:slutt) %number of different r values: n
    m = 2^(slutt+3);   %400             %number of different theta values: m

% Values of radius and angle (theta)
theta = linspace(0,2*pi,m+1); %T(:,1); % 
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points
r = linspace(r0,r1,n);% R(1,:); %  n points


%% Numerical solution
%Call function to get solution
%First order ME, second order discretization of Helmholtz:
[R,T,S] = Five_point_polar(m,n,r,theta,ny,P0);
% R = radius, T = theta, S = solution

%Second order ME, second order discretization of Helmholtz:
% [R,T,S] = Five_point_polar_2(m,n,r,theta,ny,P0);


%% Analytical solution, scatter wave P_s
% Analytic solution found on p. 30 in 
% Ihlenburg: Finite element analysis of acoustic scattering (1998)
sum = 0;
    % Sum in formula
    for it = 1:20
        sum = sum + (1i^it)*cos(it*T)*bJderZ(it,ny*r0).*besselh(it,ny*R)./(HderZ(it,ny*r0)); 
    end
    term1 = (1/2)*(1i^0)*cos(0*T)*bJderZ(0,ny*r0).*besselh(0,ny*R)./(HderZ(0,ny*r0));

    p_s = -2*P0*(term1 + sum); % Final wave
    
    
%% Error computation and error plot
abs_err = abs(S-p_s);               % Absolute error
rel_err = abs_err./p_s;               % Relative error;
delta_r(p) = R(1,2)-R(1,1);         % Changes
delta_theta(p) = T(2,1)-T(1,1);     % Same in every iteration when m is fixed

% Can change from abs to rel_err
%norm_err(p) = norm(abs_err,Inf);
norm_err(p) = norm(abs_err,'fro')*sqrt(delta_r(p)*delta_theta(p));
% Max norm/infnorm => Don't have to use scaling by sqrt(h*k)

p = p+1;

end


%% Find error in r direction while theta is fixed, 2nd order ME
% Switch n and m = > error in theta while r is fixed
for n = 2.^(start:inkr:slutt) %number of different r values
    m = 2^(slutt+3);   %400             %number of different theta values

% Values of radius and angle (theta)
theta = linspace(0,2*pi,m+1); %T(:,1); % 
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points
r = linspace(r0,r1,n);% R(1,:); %  n points


%% Numerical solution
%Call function to get solution
%First order ME, second order discretization of Helmholtz:
% [R,T,S] = Five_point_polar(m,n,r,theta,ny,P0);
% R = radius, T = theta, S = solution

%Second order ME, second order discretization of Helmholtz:
[R,T,S] = Five_point_polar_2(m,n,r,theta,ny,P0);


%% Analytical solution, scatter wave P_s
% Analytic solution found on p. 30 in 
% Ihlenburg: Finite element analysis of acoustic scattering (1998)
sum = 0;
    % Sum in formula
    for it = 1:20
        sum = sum + (1i^it)*cos(it*T)*bJderZ(it,ny*r0).*besselh(it,ny*R)./(HderZ(it,ny*r0)); 
    end
    term1 = (1/2)*(1i^0)*cos(0*T)*bJderZ(0,ny*r0).*besselh(0,ny*R)./(HderZ(0,ny*r0));

    p_s = -2*P0*(term1 + sum); % Final wave
    
    
%% Error computation and error plot
abs_err = abs(S-p_s);               % Absolute error
rel_err = abs_err./p_s;               % Relative error;
delta_r2(p) = R(1,2)-R(1,1);         % Changes
delta_theta2(p) = T(2,1)-T(1,1);     % Same in every iteration when m is fixed

% Can change from abs to rel_err
%norm_err(p) = norm(abs_err,Inf);
norm_err2(p) = norm(abs_err,'fro')*sqrt(delta_r2(p)*delta_theta2(p));
% Max norm/infnorm => Don't have to use scaling by sqrt(h*k)

p = p+1;

end


%%  Error plots

% Error in r-direction
figure()
loglog(delta_r,norm_err,'*-')
hold on
loglog(delta_r2,norm_err2,'o-')
loglog(delta_r, delta_r.^2,'--')
title('Error in r', 'LineWidth', 15)
xlabel('\Delta r', 'LineWidth',14)
ylabel('Norm of the error','LineWidth',14)
legend('1^{st} order absorbing boundary','2^{nd} order absorbing boundary', 'Line of reference, (\Delta r)^2')






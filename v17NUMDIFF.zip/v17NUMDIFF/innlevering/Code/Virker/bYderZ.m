function [ der ] = bYderZ( ny,Z )
%Helperfunction 02
der=(ny./Z).*bessely(ny,Z)-bessely(ny+1,Z);
end


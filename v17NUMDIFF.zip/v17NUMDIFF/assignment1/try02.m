function [ output1 ] = try02( alpha, beta )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


end


%
%Solve systems of linear equations Ax = B for x
% x = A\B
%
%openExample('matlab/LinearSystemwithSingularMatrixExample')
%
% you can pass a handle to an anonymous function to function function
fun = @(x)x./(exp(x)-1); %anonymous function of x, fun(x)=x./(exp(x)-1)
q4 = integral(fun,0,Inf) %function function
%or you can make a function into a function handle
f = @myfunction
%
%
%
%
%

%We want AU=F
%list of variables we need, initialized to something
f=@(x)sin(x*pi/2) %a function, for now it is sin(x*pi/2)
alpha = sin %u(0)=alpha
beta = %u(1)=beta
h


%Construct A
%Construct F



%Find numerical solution: U=A/F

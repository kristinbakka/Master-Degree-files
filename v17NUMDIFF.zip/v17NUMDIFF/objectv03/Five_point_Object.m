function [X,Y,retU,G]= Five_point_Object(h,M,k,N,x0,y0,gx0,gx1,gy0,gy1,ny,object)   
ind=setdiff(1:(M*N),object);

%Make A

e  = ones(M*N,1);
v0 = (-2*(1/k^2+1/h^2)+ny.^2)*e;
vb = e/(k^2);
vm1= repmat([ones(M-1,1);0]*(1/h^2),N,1);
v1 = repmat([0;ones(M-1,1)]*(1/h^2),N,1);

A = spdiags([vb,vm1, v0, v1,vb], [-M,-1:1,M],M*N,M*N);
%The unknown points:
i=1:M;
X=(x0+ i*h)';

j=1:N;
Y=(y0+j*k)';

%Make G
%Outer Boundary
G=sparse(N*M,1);
% %i=1: %
 G(M*(j-1)+1)=G(M*(j-1)+1)+(1/h^2)*gx0(Y(j)); %venstre
% %i=M:
 G(M*(j-1)+M)=G(M*(j-1)+M)+(1/h^2)*gx1(Y(j)); %hoyre
% %j=1:
 G(i)=G(i)+(1/k^2)*gy0(X(i)); %under
%j=N:
G(M*(N-1)+i)=G(M*(N-1)+i)+1/k^2*gy1(X(i)); %over

%Inner boundary:
%med Dirichlet conditions 0 i f�rste omgang.
B=sparse(N*M,1);
%computes for all elements next to object, including for points in object.
%this is okay, as points in object are discarded in next step

% right boundary:
 B(object+1)=B(object+1)+(1/h^2)*zeros(length(object),1); %object til venstre
% left boundary:
 B(object-1)=B(object-1)+(1/h^2)*zeros(length(object),1); %object til hoyre
% top boundery:
 B(object+M)=B(object+M)+(1/k^2)*zeros(length(object),1); %object under
% bottom boundary:
 B(object-M)=B(object-M)+1/k^2*zeros(length(object),1); %object over

%remove object
A = A(ind,ind);
G = G(ind) + B(ind);

%solve
U=A\(-G);

%Put back values
retU=zeros(M*N,1);
retU(object)=nan;
retU(ind)=U;

end
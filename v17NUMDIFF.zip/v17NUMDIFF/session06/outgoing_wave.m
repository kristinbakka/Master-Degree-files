m = 20; %number of different theta values
n = 30; %number of different r values

r0=0.8;
ny_5 = 2;
P0=5;

theta = linspace(0,2*pi,m+1);
%%Include this to avoid two representations of same point (0 and 2*pi)
%theta = theta(1:m);

%make a grid
r = linspace(r0,5,n);
[R,T] = meshgrid(r,theta);
%function of grid
x=R.*cos(T);
y=R.*sin(T);

z = P0.*exp(1i.*ny_5.*R.*cos(T));

%translate grid for plotting
x = R.*cos(T);
y = R.*sin(T);

s=surf(x,y,real(z));
xlabel('x-axis')
s.EdgeColor = 'none';
xlabel('x-axis')
ylabel('y-axis')
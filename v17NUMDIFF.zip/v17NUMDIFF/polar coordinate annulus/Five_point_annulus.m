function [X,Y,retU,G]= Five_point_annulus(h,m,k,n,t0,rho0,gr1,grn, ny)   
% n = antall forskjellige rader (radier)
% N = antall ukjente verdier dirichlet begge ender = n-2

%Make A

e  = ones(m*n,1);
v0 = (-2*(1/k^2+1/h^2)+ny.^2)*e;
vb = e/(k^2);
vm1= repmat([ones(m-1,1);0]*(1/h^2),n,1);
v1 = repmat([0;ones(m-1,1)]*(1/h^2),n,1);

A = spdiags([vb,vm1, v0, v1,vb], [-m,-1:1,m],m*n,m*n);
inner_boundary = spdiags(m,2*m);
outer_boundary = spdiags(m,2*m);

A(1:m,1:(2*m)) = inner_boundary;
A(m*n - m + 1:m,m*n - 2*m + 1:(2*m)) = outer_boundary;

%Make G
G=sparse(m*n,1);
%index helper
i=1:m;

%%Neumann:
% inner boundary circle %(= 0th circle)
 G(i)= zeros(m,1);
%%Mayda-Enquist:
% outer boundary circle %(= (N+1)th circle)
 G(m*n - m + i)= zeros(m,1);

 %some more boundary values
% 1st circle
 G(i+m)= ones(m,1);
% Nth circle
 G(m*n - 2*m + i)= ones(m,1)*0.01;

%Remove biggest radius as long as Mayda Enquist is not ready
 G=G(1:(end-m));
 A=A(1:(end-m),1:(end-m));
 
%Remove first radius as long as Neumann inner is not ready
 G=G((m+1):end);
 A=A((m+1):end,(m+1):end);

%solve
U=A\(-G);

%Put back values?
%plot boundary values as well?
retU = full(reshape(U, m, n-2));

end
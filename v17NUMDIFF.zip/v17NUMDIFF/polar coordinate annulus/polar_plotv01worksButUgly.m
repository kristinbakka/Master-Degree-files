clear
m = 100; %number of different theta values
n = 50; %number of different r values
N = n-2;

r0= 0.5;
r1= 5;

P0=5;
ny=0.2;


%values of rho and theta
theta = linspace(0,2*pi,m+1);
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points

%make a grid
r = linspace(r0,5,n); % n points
%r(2)=0.2;r(4)=4;
[R,T] = meshgrid(r,theta);
%function of grid
z = P0./R;

% %translate grid for plotting
% x = R.*cos(T);
% y = R.*sin(T);
% 
% surf(x,y,z);

%index meshgrid
%[Ri,Ti]= meshgrid(1:n,1:m);

%Only for meaty part:
%k and h
k_top = r(3:end)-r(2:(end-1));
k_bottom = r(2:(end-1))-r(1:(end-2));

h = 2.*pi.*r(2:(end-1))./m;

%as meshgrids
K_top = repmat(k_top,m,1); %same for every theta
K_bottom = repmat(k_bottom,m,1); %same for every theta
H = repmat(h,m,1); %same for every theta

%calculate the different values:
%expression derived from imagination, not mathematics:
me = (-2.*(((K_top+K_bottom)/2).^(-2)+ H.^(-2)) + ny.^2);
right = H.^(-2);
left = right;
%expression derived from imagination, not mathematics: 
%                 (discretize again properly to check what it should be)
top = K_top.^(-2); 
bottom = K_bottom.^(-2);


%%Make A
%me
v0= [zeros(m,1);me(:);zeros(m,1)];
%top:
vt=[zeros(2*m,1);top(:)];
%bottom:
vb=[bottom(:);zeros(2*m,1)];

%right:
%v1 = [zeros(1,N);right(1:(m-1),:)](:);
temp=[zeros(1,N);right(1:(m-1),:)];
v1= [zeros(m,1);temp(:);zeros(m,1)];
%left:
%vm1= [left(2:m,:);zeros(1,N)](:);
temp=[left(2:m,:);zeros(1,N)];
vm1= [zeros(m,1);temp(:);zeros(m,1)];

A = spdiags([vb,vm1, v0, v1,vt], [-m,-1:1,m],m*n,m*n);
%over flow points on right/left
%helping iterator
iteratorN=(1:(n-2));
%right:
A(sub2ind(size(A),(iteratorN+1).*m,iteratorN.*m+1))=right(m,:);
%left:
A(sub2ind(size(A),iteratorN.*m+1,(iteratorN+1).*m))=left(1,:);
%B=full(A);
inner_boundary = spdiags(m,2*m);
outer_boundary = spdiags(m,2*m);

A(1:m,1:(2*m)) = inner_boundary;
A(m*n - m + 1:m,m*n - 2*m + 1:(2*m))=outer_boundary;

%TODO: plot full(A) for different values to determine correctness
%what do I need for function?
%values of r and theta
    %gives: K, H
%number of observations m,n
%B=full(A);

%NB: I have decided first point always theta=0, always full circle. Easy to
%modify if wanted
%could make different H_left and H_right if desired
%%%%%Continue the solver:
%Make G
G=sparse(m*n,1);
%index helper
i=1:m;

%%Neumann:
% inner boundary circle %(= 0th circle)
 G(i)= zeros(m,1);
%%Mayda-Enquist:
% outer boundary circle %(= (N+1)th circle)
 G(m*n - m + i)= zeros(m,1);

 %some more boundary values
% 1st circle
 %G(i+m)= ones(m,1); %or try with other fun stuff :D
 G(i+m)= sin(theta); %or try with other fun stuff :D
% Nth circle
 %G(m*n - 2*m + i)= ones(m,1)*0.01;
 G(m*n - 2*m + i)= cos(theta.*4);
%Remove biggest radius as long as Mayda Enquist is not ready
 G=G(1:(end-m));
 A=A(1:(end-m),1:(end-m));
 
%Remove first radius as long as Neumann inner is not ready
 G=G((m+1):end);
 A=A((m+1):end,(m+1):end);

%solve
U=A\(-G);

%Put back values?
%plot boundary values as well?
retU = full(reshape(U, m, n-2));

%plot av bare 'meat'
x = R(:,2:(n-1)).*cos(T(:,2:(n-1)));
y = R(:,2:(n-1)).*sin(T(:,2:(n-1)));
%[R,T] = meshgrid(r,theta);

plotx = [x;R(1,2:(n-1)).*cos(2*pi)];
ploty = [y;R(1,2:(n-1)).*sin(2*pi)];
plotU = [retU;retU(end,:)];

% plotx = [x];
% ploty = [y];
% plotU = [retU];

surf(plotx,ploty,plotU);

%surf(R.*cos(T),R.*sin(T),z);



%Modelling object 1
%Planb�lge:
x0=0;
xend=5;
%for numerical plotting:
 M=50;
h=(xend-x0)/(M+1);

y0=0;
yend=20;
%for numerical plotting:
 N=100;
 k=(yend-y0)/(N+1);
 
gx0= @(y) sin(pi*y/2);
gx1=@(y) sin(pi*y/2);
gy0= @(x) 0;%sin(y0*pi);
gy1= @(x) 0;%sin(yend*pi);
ny=pi/2;


[X,Y,U,G]= Five_point_annulus(h,m,k,n,t0,r0,gr0,gr1, ny);

tUmat=vec2mat(U,M); %matrix with N rows and M columns, same as Umat'

%Plott l�sningen: 
figure(1)
surf(X,Y,tUmat)
xlabel('x','FontSize',14)
ylabel('y','FontSize',14)
zlabel('Solution','FontSize',14)
title('Numerical Solution','FontSize',16)

%annet:

% hold on;
% surf(X,Y,objectprint)
% xlabel('x','FontSize',14)
% ylabel('y','FontSize',14)
% zlabel('Solution','FontSize',14)
% title('Numerical Solution','FontSize',16)

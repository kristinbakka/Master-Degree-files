clear

M=10;
N=8;
multiplier=1;
y_a=1;
x_a=2;
length=4;

[t_top,t_bottom,t_right,delete]= triangle_creator(M,N,multiplier,x_a,y_a,length);  



%%Testing:
tester=zeros(M,N);
tester(t_top)=1;
tester(t_bottom)=2;
tester(t_right)=3;
tester(delete)=5;

[X,Y]=meshgrid(1:3,2:5);
Z=X;

surf(X,Y, Z);
xlabel('x')
ylabel('y')
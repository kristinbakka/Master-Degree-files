testmat_1=[1,2,3,4;5,6,7,8;9,10,11,12];
testvec_02= 1:12;
testvec_02=testvec_02';
testmat_02= (vec2mat(testvec_02,4))';


testmat_02(5)=0;

%


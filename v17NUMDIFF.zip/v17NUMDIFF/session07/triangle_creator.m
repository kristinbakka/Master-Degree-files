function [triangle_top,triangle_bottom,triangle_right,delete]= triangle_creator(M,N,multiplier,x_a,y_a,length)   
%The triangle has three sides. Top and bottom "er beina i den likebente
%trekanten", right is the right vertical side. The sharp end of the
%triangle is where top and bottom meet.
%
%Output variables:
%Vectors of indices of the borderpoints of the triangle in U after 
%size of U has increased due to the multiplier.
%triangle_top,triangle_bottom and triangle_right are vectors of 
%their respective indices. Knots are counted twice.
%That is the sharp end is included both in triangle_top and triangle_bottom
%delete contains the indices that should be deleted
%
%Input variables:
%M and N are rows and columns of original matrix
%x_a and y_a are the position in original matrix of the imaginary top left
%corner of the matrix
%Amount of grid lines are multiplied when multiplier=2. That means k=k/2
%and h=h/2. It is not possible to edit only one of them. Multiplier can be
%any natural number 1, 2, 3, ...
%length is number of points on the x_axis the original triangle covers

% Change grid size
k2=multiplier*(length-1);

M=M*multiplier;%rows, that is number of x'es
N=N*multiplier;%cols, that is number of y'es

% Generate indexes of top, bottom, right
top_column=((k2+1):(2*k2+1));
bottom_column=((k2+1):-1:1);
tb_row=1:(k2+1);

rightside_column=1:(2*k2+1);
rightside_row=ones(1,2*k2+1)*(k2+1);

% Position after multiplier
x_pos=(x_a-1)*multiplier+1;
y_pos=(y_a-1)*multiplier+1;

% Incorporate position of imaginary top left corner
top_column = top_column +y_pos -1;
bottom_column = bottom_column +y_pos -1;
rightside_column = rightside_column +y_pos -1;

tb_row = tb_row + x_pos -1;
rightside_row = rightside_row +x_pos -1;

% Convert (row,col)-indices to indices of U 
triangle_top = sub2ind([M N],tb_row, top_column);
triangle_bottom = sub2ind([M N],tb_row, bottom_column);

triangle_right = sub2ind([M N],rightside_row, rightside_column);

%%Index of object to remove:
delete=1:(k2-1)^2;
place=0;
for i = 1:(k2-1)
    delete((1:i)+place)=triangle_bottom(end-1-i)+(1:i);
    place=place+i;
    
    delete((1:i)+place)=triangle_top(end-1-i)+(1:i);
    place=place+i;
end

end






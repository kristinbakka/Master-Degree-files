clear
%multiply with two=split the grid in half (only kind of split allowed (?))
%I think. :)
multiplier=2;
k1=3;
k2=multiplier*k1;

M=7*multiplier;%rows, that is number of x'es
N=8*multiplier;%cols, that is number of y'es



%generate indexes of matrix 
top_column=((k2+1):(2*k2+1));
bottom_column=((k2+1):-1:1);
tb_row=1:(k2+1);

rightside_column=1:(2*k2+1);
rightside_row=ones(1,2*k2+1)*(k2+1);

%position of imaginary top left corner
x_a=1;
y_a=1;

%Position after multiplier
x_pos=(x_a-1)*multiplier+1;
y_pos=(y_a-1)*multiplier+1;

%Incorporate position of imaginary top left corner
top_column = top_column +y_pos -1;
bottom_column = bottom_column +y_pos -1;
rightside_column = rightside_column +y_pos -1;

tb_row = tb_row + x_pos -1;
rightside_row = rightside_row +x_pos -1;

%%Convert indexes to index of 

triangle_top = sub2ind([M N],tb_row, top_column);
triangle_bottom = sub2ind([M N],tb_row, bottom_column);

triangle_right = sub2ind([M N],rightside_row, rightside_column);

%%Index of object to remove:
delete=1:(k2-1)^2;
place=0;
for i = 1:(k2-1)
    delete((1:i)+place)=triangle_bottom(end-1-i)+(1:i);
    place=place+i;
    
    delete((1:i)+place)=triangle_top(end-1-i)+(1:i);
    place=place+i;
end


%%Testing:
tester=zeros(M,N);
tester(triangle_top)=1;
tester(triangle_bottom)=2;
tester(triangle_right)=3;
tester(delete)=5;








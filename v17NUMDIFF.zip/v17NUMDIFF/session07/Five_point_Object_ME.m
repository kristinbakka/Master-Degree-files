function [retU,G]= Five_point_Object_ME(h,M,k,N,A0,a,b,xend,yend,t_top,t_bottom,t_right,delete);
%ADD DESCRIPTION HERE
keep=setdiff(1:(M*N),delete);
ny=sqrt(a^2+b^2);

%% Make A
% Internal part of A
e  = ones(M*N,1);
v0 = (-2*(1/k^2+1/h^2)+ny.^2)*e;
vbm1 = e/(k^2);
vb1=e/(k^2);
vm1= repmat(ones(M,1)*(1/h^2),N,1); %left node
v1 = repmat(ones(M-2,1)*(1/h^2),N,1); %right node
%The unknown points:
t=1:M;
j=1:N;

% Absorbing boundary part of A
% %t=1: 
%venstre
 v0(M*(j-1)+1)=(1i*ny+1/h);
 vm1(M*(j-1)+1)=0;
 v1(M*(j-1)+1)=-1/h;
 vbm1(M*(j-1)+1)=0;
 vb1(M*(j-1)+1)=0;
% %t=M:
%hoyre
 v0(M*(j-1)+M)=(1i*ny+1/h);
 vm1(M*(j-1)+M)=-1/h;
 v1(M*(j-1)+M)=0;
 vbm1(M*(j-1)+M)=0;
 vb1(M*(j-1)+M)=0;
% %j=1:
%under
 v0(t)=(1i*ny+1/k);
 vm1(t)=0; 
 v1(t)=0;
 vbm1(t)=0;
 vb1(t)=-1/k;
%j=N:
%over
v0(M*(N-1)+t)= (1i*ny+1/k);
vm1(M*(N-1)+t)=0;
v1(M*(N-1)+t)=0;
vbm1(M*(N-1)+t)=-1/k;
vb1(M*(N-1)+t)= 0;

% Generate A
A = spdiags([vbm1,vm1, v0, v1,vb1], [-M,-1:1,M],M*N,M*N);
%AU + G = 0
%The first N elements of U correspond to y_1, the second N correspond to
%y_2 etc. The first element corresponds to x_1, second to x_2

% Boundary conditions of Triangle
%triangle_top:
%the nodes on the boundary t_top
A(t_top,t_top)=A(t_top,t_top)+ones(length(t_top));
%to the right of t_top
A(t_top+1,t_top+1)=A(t_top+1,t_top+1)+ones(length(t_top));
%above t_top
A(t_top+M,t_top+M)=A(t_top+M,t_top+M)+ones(length(t_top));

%triangle_bottom:
%the nodes on the boundary t_bottom
A(t_bottom,t_bottom)=A(t_bottom,t_bottom)+ones(length(t_bottom));
%to the left of t_top
A(t_top-1,t_top-1)=A(t_top-1,t_top-1)+ones(length(t_bottom));
%below t_bottom
A(t_bottom-M,t_bottom-M)=A(t_bottom-M,t_bottom-M)+ones(length(t_bottom));

%triangle_right:
%the nodes on the boundary t_right
A(t_right,t_right)=A(t_right,t_right)+ones(length(t_right));
%to the right of t_right
A(t_right+1,t_right+1)=A(t_right+1,t_right+1)+ones(length(t_right));

%% Make G
%NB: AU+G=0; 
%(Outer Boundary)
G=sparse(N*M,1);
% %t=1: %
 G(M*(j-1)+1)=-A0*(a-ny)*1i*exp(1i*b*k*j); %venstre
% %t=M:
 G(M*(j-1)+M)=A0*(a+ny)*1i*exp(1i*(a*xend+b*k*j)); %hoyre
% %j=1:
 G(t)=-A0*(b-ny)*1i*exp(1i*a*t*h); %under
%j=N:
G(M*(N-1)+t)=A0*(b+ny)*1i*exp(1i*(a*t*h+b*yend)); %over

%Inner boundary:
B=sparse(N*M,1);

% triangle_top
% top boundery:
B(t_top)=B(t_top)+ones(length(t_top),1); %object is under
% top boundery:
B(t_bottom)=B(t_bottom)+ones(length(t_bottom),1); %object is over
% top boundery:
B(t_right)=B(t_right)+ones(length(t_right),1); %object is to the left

%remove object
A = A(keep,keep);
G = G(keep) + B(keep);

%% Solve
U=A\(-G);

%% Resize and return
%Put back values
retU=zeros(M*N,1);
retU(delete)=NaN;
retU(keep)=U;

%make it into plot shaped matrix
retU=vec2mat(retU,M); %matrix with M rows and N columns,
%this is already flipped and ready for plotting.
%N is number of different ys, M is number of different xes.
%so each column contains the same x, each row contains the same y
%the command itself translates the vector. I.e. The vector is put in the
%matrix row-wise

end
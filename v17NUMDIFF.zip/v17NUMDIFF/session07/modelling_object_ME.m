clear
%AU + G = 0
%
%Hei Inger, Karine og Gina :)
%Nå er jeg ferdig med trapes-koden, og jeg mener at den er riktig.
%
%1-Kjør igjennom koden og se hva jeg gjør.
%1.1-På linje 70([U_scat,G]= Five_point_Object_ME(..); plasser et breakpoint, 
%og åpne U_tester for å se hvor i U trekanten havner.
%Trekanten er ikke opp ned, matlabs representasjon er 'opp-ned'
%1.2-Kjør igjennom og se på U_scat, se at boundary har havnet samme sted
%
%2-Plasser inn boundary conditions på objektet
% uttrykket er AU+G+B=0
%2.1- plasser inn B-verdiene fra linje 95 i Five_point_Object_ME
%2.2- plasser inn verdiene som skal i A fra linje 54 i Five_point_Object_ME
%
%3-Kjør koden med ulike antall M og N
%Med lik plassering og form på trekanten må antallet gridpunkt være et 
%heltall multiplum av opprinnelig M
%skriv f.eks
%multiplier=4;
%[t_top,t_bottom,t_right,delete]= triangle_creator(M,N,multiplier,x_a,y_a,length);  
%[U_scat,G]= Five_point_Object_ME(h/multiplier,M*multiplier,k/multiplier,N*multiplier,A0,a,b,xend,yend,t_top,t_bottom,t_right,delete);
%[X,Y] = meshgrid(linspace(x0,xend,M*multiplier),linspacey(y0,yend,N*multiplier));
%U_inc=A0.*exp(1i.*(a.*X+b.*Y));
%U_tot= (U_scat+U_inc);
%Surf(X,Y,real(U_tot));


%Comments:
%The first N elements of U correspond to y_1, the second N correspond to
%y_2 etc. The first element corresponds to x_1, second to x_2
%When X, Y, U_inc, U_tot etcetera are finished they are converted to
%flipped matrices ready for plotting
%All the matrices that require plotting are generated ready for plotting

A0=1;
a=pi;
b=pi;
ny=sqrt(a^2 + b^2);

%x0 m� v�re 0:
x0=0;
xend=1;
M=10; %M is number of points including boundary points, i.e rows
h=(xend-x0)/(M-1);
xvec=linspace(x0,xend,M);

%y0 m� v�re 0:
y0=0;
yend=1;
N=12; %N is number of points including boundary points
k=(yend-y0)/(N-1);
yvec=linspace(y0,yend,N);

%Plane wave
%u_inc= A0exp{i*(ax+by)} 
[X,Y] = meshgrid(xvec,yvec);
U_inc=A0.*exp(1i.*(a.*X+b.*Y));

%Triangle
multiplier=1;
%NB: can't be right next to a "wall"
%i.e  1 < x_a < M-(1ength of triangle)
%i.e  1 < y_a < N-(height of triangle)
% where 
y_a=3;
x_a=2;
length=4; %NB: height is 2*length-1

[t_top,t_bottom,t_right,delete]= triangle_creator(M,N,multiplier,x_a,y_a,length);  

%----test that the triangle ended up inside bounds
%nb: high y's are down in the matrix
U_test=zeros(M*N,1);
U_test(t_top)=1;
U_test(t_bottom)=2;
U_test(t_right)=3;
U_test(delete)=NaN;
U_tester=vec2mat(U_test,M);
%NB: matlab plots every column as the same X, every row as the same y
%i.e
% (x1,y1) (x2,y1) (x3,y1)
% (x1,y2) (x2,y2) (x3,y2)
% (x1,y3) (x2,y3) (x3,y3)
% (x1,y4) (x2,y4) (x3,y4)
%and this is how the matrix is represented
%so the top boundary ends up at the bottom
%---------det over og til neste -- kan slettes, er "bare" for forståelse :)

[U_scat,G]= Five_point_Object_ME(h,M,k,N,A0,a,b,xend,yend,t_top,t_bottom,t_right,delete);


U_tot= (U_scat+U_inc);

%Plot solution: 
figure(1)
surf(X,Y,real(U_tot));
xlabel('x','FontSize',14)
ylabel('y','FontSize',14)
zlabel('Solution','FontSize',14)
title('Numerical Solution','FontSize',16)
%NB: matlab plots every column as the same X, every row as the same y
%i.e
% (x1,y1) (x2,y1) (x3,y1)
% (x1,y2) (x2,y2) (x3,y2)
% (x1,y3) (x2,y3) (x3,y3)
% (x1,y4) (x2,y4) (x3,y4)
%and this is how the matrices are represented

clear
m = 600; %number of different theta values
n = 800; %number of different r values
N = n-2;


r0= 0.5;
r1= 10;

P0=5;
ny=4; %ny from helmholtz
%ny_5=ny; %ny from incoming wave
%ny_2= ny; %ny from Mayda-Enquist


%values of radius and angle (theta)
theta = linspace(0,2*pi,m+1);
%%Include this to avoid two representations of same point (0 and 2*pi)
theta = theta(1:m); % m points
r = linspace(r0,r1,n); % n points

%call function to get solution
%First order ME:
[R,T,U_s] = Five_point_polar(m,n,r,theta,ny,P0);
%Second order ME:
%[R,T,S] = Five_point_polar_2(m,n,r,theta,ny,P0);
%incoming wave
U_i = P0.*exp(1i.*ny.*R.*cos(T)); 

%oversett til kartesiske koordinater
x = R.*cos(T);
y = R.*sin(T);
%legg p� theta=2*pi, slik at det blir komplett grid
plotx = [x;R(1,:).*cos(2*pi)];
ploty = [y;R(1,:).*sin(2*pi)];
plotU_s = [U_s;U_s(1,:)];
plotU_i= [U_i;U_i(1,:)];

%plott
%s_p=surf(plotx,ploty,real(plotU));
s_p=surf(plotx,ploty,real(plotU_s+plotU_i));
%s_p=surf(plotx,ploty,real(plotu_i));

s_p.EdgeColor = 'none';
%surf(plotx,ploty,imag(plotU));
xlabel('x','FontSize',14)
ylabel('y','FontSize',14)
zlabel('Solution','FontSize',14)
title('Numerical Solution','FontSize',16)

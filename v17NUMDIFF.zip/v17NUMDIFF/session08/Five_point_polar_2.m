function [R,T,retU]= Five_point_polar_2(m,n,r,theta,ny,P0)   

%%(1) Generate representations of values of k and h
%Only for internal ("meaty") part:
N=n-2;
[R_m,T_m] = meshgrid(r(2:(n-1)),theta);
%k and h
k_top = r(3:end)-r(2:(end-1));
k_bottom = r(2:(end-1))-r(1:(end-2));
h = (2.*pi./m).*r(2:(end-1)); %Lenght between the nodes (not just delta theta)

%as meshgrids
K_top = repmat(k_top,m,1); %same for every theta
K_bottom = repmat(k_bottom,m,1); %same for every theta
K = ((K_top+K_bottom)./2);%expression derived from imagination, not mathematics: 
%                 (discretize again properly to check what it should be)
H = repmat(h,m,1); %same for every theta

%%(2) Calculate coefficient left/right over/under interior node
center = (-2.*(K.^(-2)+ (H.*R_m).^(-2)) + ny.^2);
right = (H.*R_m).^(-2);
left = right;
top = K.^(-2)+(2.*K.*R_m).^(-1); 
bottom = K.^(-2)-(2.*K.*R_m).^(-1);


%%(3)---Make A-------------------
%%(3.1) Interior of domain ('meaty part')
%center:
v0= [zeros(m,1);center(:);zeros(m,1)];
%top:
vt=[zeros(2*m,1);top(:)];
%bottom:
vb=[bottom(:);zeros(2*m,1)];

%right:
%v1 = [zeros(1,N);right(1:(m-1),:)](:);
temp=[zeros(1,N);right(1:(m-1),:)];
v1= [zeros(m,1);temp(:);zeros(m,1)];
%left:
%vm1= [left(2:m,:);zeros(1,N)](:);
temp=[left(2:m,:);zeros(1,N)];
vm1= [zeros(m,1);temp(:);zeros(m,1)];

%%(3.2) Construct A
A = spdiags([vb,vm1, v0, v1,vt], [-m,-1:1,m],m*n,m*n);

%%(3.3) FIX over flow points on right/left of interior nodes
%helping iterator
iteratorN=(1:(n-2));
%right:
A(sub2ind(size(A),(iteratorN+1).*m,iteratorN.*m+1))=right(m,:);
%left:
A(sub2ind(size(A),iteratorN.*m+1,(iteratorN+1).*m))=left(1,:);

%%(3.4) Fill in expressions for inner and outer boundary
inner_boundary = sparse(m,2*m);
inner_boundary(:,1:m)= spdiags(ones(m,1),0,m,m);
inner_boundary(:,(m+1):end)= spdiags(-ones(m,1),0,m,m);

outer_boundary = sparse(m,2*m);
%k and h for outer boundary
k_ob = r(end)-r(end-1);
h_ob=  2.*pi./m.*r(end);

theta_const= -(1i/(2*ny*r(end)^2)+ 1/(2*ny^2*r(end)^3));
left_right_const= theta_const*1/(h_ob^2)+((-k_ob^2)/(2*r(end)*k_ob+k_ob^2))*(1/(h_ob^2*r(end)));

%the nodes below:
outer_boundary(:,1:m)= spdiags(-1/(2*k_ob)*(1+(2*r(end)*k_ob^3)/(2*r(end)*k_ob+k_ob^2)*(1/k_ob^2-1/(2*k_ob*r(end))))*ones(m,1),0,m,m);
%the nodes themselves:
%HVA GJ�R VI MED u^2?? N� er det ignorert.
vnode=(((-r(end)*k_ob^2)/(2*r(end)*k_ob+k_ob^2))*(-2/k_ob^2 - 2/(h_ob^2*r(end)^2) + ny^2)-(1i.*ny - 1/(2.*r(end)))+theta_const*(-2/h_ob^2)).*ones(m,1);
rightnode=left_right_const*ones(m,1);
leftnode= rightnode;
outer_boundary(:,(m+1):(2*m)) = spdiags([rightnode,vnode ,leftnode],[-1,0,1],m,m);
outer_boundary(1,end)= left_right_const;%rightnode of the first node
outer_boundary(end,1)= left_right_const; %leftnode of the last node


%%(3.5) Insert expressions of inner and outer boundary in A
A(1:m,1:(2*m)) = inner_boundary;
A((end-m+1):end,(end-2*m+1):end) = outer_boundary;
%-------finished making A-----

%(4)---Make G--------------------
% AU + G = 0
%%(4.1) Allocate and make iterator
G=sparse(m*n,1);
%index helper
iteratorM=1:m;

%%(4.2) Fill in inner boundary
%%Neumann:
% inner boundary circle %(= 0th circle)
 G(iteratorM)= -(r(2)-r(1)).*P0.*1i.*ny.*cos(theta).*exp(1i.*ny.*r(1).*cos(theta));
% 1st circle
    %I don't think you need 1st circle, but it is fun to play with ^^
 %G(i+m)= ones(m,1); %or try with other fun stuff :D
 %G(iteratorM+m)= exp(1i.*ny.*theta); %or try with other fun stuff :D
 
%%(4.3) Fill in outer boundary
%%Mayda-Enquist:
% outer boundary circle %(= (N+1)th circle)

%Har tatt med u^2 her
u_inc=P0.*exp(1i.*ny.*r(end).*cos(theta));
 G(m*n - m + iteratorM)= u_inc.*(1i.*ny.*cos(theta)+(1i./(2.*ny.^2.*r(end).^2)...
     + 1./(2.*ny.*r(end))).*(ny.^2.*r(end).^2.*sin(theta).^2 +1i.*ny.*r(end).*cos(theta)))-(1i.*ny-1./(2.*r(end))).*u_inc.^2 ;
% Nth circle
 %G(m*n - 2*m + i)= ones(m,1)*0.01;
 %G(m*n - 2*m + iteratorM)= cos(theta.*4);
%-------finished making G-----

%(5)---Shorten G and A-----------
    %(so the code can run before BC's are complete)
%Remove biggest radius as long as Mayda-Enquist is not ready, 
    %or if M-E doesn't need it
 %G=G(1:(end-m));
 %A=A(1:(end-m),1:(end-m));
 
%Remove first radius as long as Neumann inner is not ready
 %G=G((m+1):end);
 %A=A((m+1):end,(m+1):end);
%---finished shortening G-----

%%(6) solve
U=A\(-G);

%%(7) Present solution in readable way
%return a matrix, not a vector
%as the code is now (March 9th)
%retU = reshape(U, m, n-2);
%if one more row is added
%retU = reshape(U, m, n-1);
%if two more rows are added
retU = reshape(U, m, n);

%%(8)Present (R,Theta) coordinate of each point

%plotter av bare interior points
%R=R_m;
%T=T_m;
%%for � plotte innerst ogs�, skriv i steden:
%%[R,T] = meshgrid(r(1:(n-1)),theta);
%%for � plotte ytterst ogs�, skriv i steden:
%[R,T] = meshgrid(r(2:(n)),theta);
[R,T] = meshgrid(r,theta);


if(size(R)~=size(retU))
    display('Size of R and retU dont mach up. They should! :D')
end
if(size(T)~=size(retU))
    display('Size of T and retU dont mach up. They should! :D')
end

end
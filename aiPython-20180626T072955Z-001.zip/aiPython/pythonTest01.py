print 'hello python'

class Walk:
   start = None #tuple, start node
   goal = None #tuple, goal node
   m = [] #node cost matrix
   myfile = None
   visual = [] #used to visualize what happened
   def __init__(self,filename):
      self.myfile = filename
      fails=0
      row=0
      for line in open(filename):
         self.visual.append(line)
         thisrow = []
         for col,char in enumerate(line):
            if char == 'r':
               thisrow.append(1)
            elif char == 'g':
               thisrow.append(5)
            elif char == 'f':
               thisrow.append(10)
            elif char == 'm':
               thisrow.append(50)
            elif char == 'w':
               thisrow.append(100)
            elif char == '#':
               thisrow.append(999999)
            elif char == '.':
               thisrow.append(1)
            elif char == 'A':
               thisrow.append(2) #hvor mye skal det koste? Er det til eller fra?
               self.start=(row,col)
            elif char == 'B':
               thisrow.append(2) #hvor mye skal det koste? Er det til eller fra?
               self.goal=(row,col)
##            elif char == '\n':
##               print empty line
##            else:
##               fails = fails+1
##               print 'fails, because char is ', char, '. (row,col) is (', row, ',',col,')' 
         row = row + 1
         self.m.append(thisrow)
      return
   def myprint(self):
      for row in self.m:
         print row
      print 'visualized by'
      for row in self.visual:
         print row
   ##tryBoard=Walk('board-2-3.txt')
   ##tryBoard.myprint()
      

class SearchNode:
    pos = None #tuple
    g = None #cost to get to node
    n = None #cost of node
    h = None #maximal minimal value to get to goal
    f = None #g+n+h
    bestParent = None #ID of (or pointer to) best parent (a closed node)
    kids = None #list of all successor nodes
    isOpen = True #open = True, or closed=false
    def __init__(self, rowcol):
        self.pos = rowcol
    def distance (self, goal):
       #the heuristic in the first part.
        return (abs(self.pos[0]-goal.pos[0])+ abs(self.pos[1]-goal.pos[1]))
   ##x=SearchNode(2,4)
   ##y=SearchNode(5,6)
   ##print x.distance(y)
   ##found = {startNode.pos: startNode}
   ##print found[(0,0)].distance(x)
   

b = Walk('board-2-3.txt')
startNode = SearchNode(b.start)
fringe = [] #sorted from lowest to highest (ascending)
closed = [] #any order
found = {startNode.pos: startNode}
   


    

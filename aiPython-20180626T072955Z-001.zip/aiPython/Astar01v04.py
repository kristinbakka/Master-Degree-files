print 'Hello Bent :D'
#planen var first at bare lage den selv, saa ikke saa pent kodet.
#det star #FIX: flere steder, det er der jeg
#med vilje ikke har brukt tid til at finne ut av syntax.
#koden kjorer derfor ikke, det er litt med vilje. kan du fikse fix? :D
#og saa har jeg vart lat og ikke lagt alt inn i klassen der det hoerer hjemme...
#beklager det og sant.
#Men jeg har kommentert en hel del masse, og der jeg ikke har folgt
#slavisk s 5 i supplement har jeg skrevet det. :)
#stor klem <3

#EDIT:
#FIX: Jeg tenker vi sier "den ekte" noden er i found hele tiden, og saa finner vi den og oppdaterer den der naar vi trenger den :)
#Det er fordi jeg fortsatt er usikker paa hvordan Python skal gjoeres
#found etc maa inn i walk-klassen
#da maa resten av funksjonene inn i Walk-klassen ogsaa
#det var egentlig hele poenget med en egen klasse for oppg 1 og 2


class SearchNode:
    pos = None #tuple, same as 'state' in hand out
    n = None #cost of node
    h = None #maximal minimal value to get to goal

    g = None #FIX: can I initialize it like this? Cost to get to node = parent.g + n
    f = None #g+h
    bestParent = None #position of best parent
    kids = None #list of positions of all successor nodes
    def __init__(self, rowcol):
        self.pos = rowcol
    def h1 (self, goal):
       #the heuristic in the first part, distance.
       self.h= (abs(self.pos[0]-goal[0])+ abs(self.pos[1]-goal[1]))
    def f1 (self):
       self.f=self.g+self.h
    def myprint(self):
       print '(',self.pos[0],',', self.pos[1], ')'
   ###How class is used
   ##x=SearchNode(2,4)
   ##y=SearchNode(5,6)
   ##print x.distance(y)
   ##found = {startNode.pos: startNode}
   ##print found[(0,0)].distance(x)

class Fringe:
   #FIX: want to remove lowest valued element sorted from lowest to highest (ascending),
   #want to be able to change values elements are sorted by

   #f is sorted highest to lowest
   f = [] #sorted list of tuples (f-value, searchNode.pos)
          #FIX: Bent: do you think it should rather be the search node itself?

   def __init__(self,searchNode):
      #make one start
      f.append(
   def push(self, searchNode):
      #create new tuple (f-value, searchNode)
      #insert new tuple so f is sorted, and new searchNode will be handled after same-valued search nodes.
   def update(self, searchNode)
      #delete old tuple
      #self.push(searchNode)

   def pop(self):
      #remove lowest from list
      #return node
   def containsNodes:
      return (len(f) != 0) #True if fringe contains nodes, False if fringe is empty


class Walk:
   start = None #tuple, start node
   goal = None #tuple, goal node
   m = [] #node cost matrix
   myfile = None
   visual = [] #used to visualize what happened
   #FIX:
   found = None #dict, contain actual nodes
   #fringe and closed contain keys of nodes (position)
   fringe = None #class Fringe
   closed = [] #list of tuples

   #found should be here  [position: searchNode]
   #fringe should be here (value, position)
   #closed should be here (value, position)

   def __init__(self,filename):
      #reads file, initiates start,goal,m,visual,found, fringe
      #i.e. it creates the board,
      #recognise start, goal, boardcost
      #puts start in nodes to explore (found)
      self.myfile = filename
      #load board:
      fails=0
      row=0
      for line in open(filename):
         self.visual.append(line)
         thisrow = []
         for col,char in enumerate(line):
            if char == 'r':
               thisrow.append(1)
            elif char == 'g':
               thisrow.append(5)
            elif char == 'f':
               thisrow.append(10)
            elif char == 'm':
               thisrow.append(50)
            elif char == 'w':
               thisrow.append(100)
            elif char == '#':
               thisrow.append(999999)
            elif char == '.':
               thisrow.append(1)
            elif char == 'A':
               thisrow.append(0) #hvor mye skal det koste? Er det til eller fra?
               self.start=(row,col)
               #assume position cost is cost to go there
               #should never return to A in search
            elif char == 'B':
               thisrow.append(1) #hvor mye skal det koste? Er det til eller fra?
               self.goal=(row,col)
##            elif char == '\n':
##               print empty line
##            else:
##               fails = fails+1
##               print 'fails, because char is ', char, '. (row,col) is (', row, ',',col,')'
         row = row + 1
         self.m.append(thisrow)

      #initialize first node
      startNode = SearchNode(self.start)
      #initialize startnode's g and n
      startNode.g = 0
      startNode.n = self.valueAt(startNode.pos)
      #calculate h and f
      startNode.h1(b.goal)
      #initialize found (nodes not to generate)
      self.found = {startNode.pos: startNode}
      #initialize fringe (same as OPEN)
      self.fringe = Fringe(startNode) 
      return
   
   def propagatePathImprovement(parent): #parent is a searchNode
      for c in parent.kids:
         child = self.found[c] #child is a node, c is a pos
         #if the child benefits from switching bestParent
         if child.bestParent.g + child.n < child.g:
            #change this child node
            child.bestParent = parent.pos
            child.g = parent.g + child.n
            child.f = child.g + child.h
            #saving changes
            self.found[c] = child 
            #parents grandchildren might benefit from choosing child as bestParent
            propagatePathImprovement(child)

   def agendaLoop(self):
   #right now: returns True if successful, False if not
      while(True):
         #nothing more to investigate
         if len(self.fringe)==0:
            print 'Uh-oh. Nothing left in fringe :9'
            return False #return fail, but I don't know how this should be written
         #now consider lowest cost node
         #FIX: assumes fringe contains positions
         xpos <- fringe.pop() #FIX: remove lowest from fringe, and work with it
         #mark x as being closed
         closed.append(xpos)

         #is X a solution?
         if xpos==self.goal:
            #FIX: return X in a sensible way and end agenda loop
            print 'goal found, it\'s', xpos, ' and it is actually supposed to be ' self.goal
            return True
         self.fringe[xpos].kids = generateAllSuccessors(xpos) #only their positions i.e. states
         for s in self.fringe[xpos].kids:
            #if new node
            if s not in self.found: #FIX: is syntax correct when found is dict, s is key?
               #initiate pos,n,h,
               #put in found and fringe
               self.foundNode(s)
               #initiate g,bestParent, f
               self.attachAndEval(s,xpos) #FIX: this func not made yet, s a pos, xpos a pos
            #if existing node and better parent
            elif x.g + found[s].n < found[s].g: 
               #update bestParent, g
               #update h?
               #update f
               #re-sort fringe (OPEN)
               attachAndEval(s,xpos) #FIX: this func not made yet s a pos, x a node
               #if the found node has children:
               if s in closed:
                  #check if children want it as bestParent
                  propagatePathImprovement(found[s])

   def attachAndEval(self,c,p):
   #get positions of existing nodes
   #initiates/changes best parent of c
   #initiates/changes g and f of c
   self.found[c].bestParent = p
   self.found[c].g = self.found[p].g + self.found[c].n
   self.found[c].f = self.found[c].g + self.found[c].h

   def foundNode(self,c,p)
   #We found a node
   #c is node position, p is parent position
   #initiates pos,n,h, and puts in found and fringe
   #put in fringe
   self.fringe.push(c)
   #give node pos,n,h
   node = SearchNode(c) #pos
   node.n = self.valueAt(c) #n
   node.h1(self.goal) #h, and cheating f
   #put in found
   self.found[c] = node
   self.attachAndEval(c,p)

   
   
   def myprint(self):
      for row in self.m:
         print row
      print 'visualized by'
      for row in self.visual:
         print row
   
   def valueAt(self, position):
      return self.m[position[0]][position[1]]
   ##tryBoard=Walk('board-2-3.txt')
   ##tryBoard.myprint()

def generateAllSuccessors(position):
   #return list of positions of legal successors
   #mark them as X'es kids
   #for walk game: up, down, left, right but not out of board
   #board is 40 columns and 10 rows
   #tuple (row number,col number)
   yourkids = []
   if (position[0]-1) >= 0:
      yourkids.append((position[0]-1, position[1]))
   if (position[0]+1) <= 9:
      yourkids.append((searchNode[0]+1, position[1]))
   if (position[1]-1) >= 0:
      yourkids.append((searchNode[0]  , position[1]-1))
   if (position[0]+1) >= 0:
      yourkids.append((position[0]  , position[1]+1))
   return yourkids

#load board from file
b = Walk('board-2-3.txt')



#after agenda loop we have found the best path to the goal
#visualize by marking open and closed nodes
#then mark the path (know end node, everyone remembers their bestParent
#visualize
#document the code
#exercise A.1 and A.2 finished
#excercise A.3 compare with BFS and Dijkstra
#Do exercise A.4? 3 points sufficient to pass,
#can reuse most code, define new h function



#now I
   #1) Put Fringe into Walk
   #2) Define a findPath-function in Walk : should find the way
   #3) Define a visualize-function in Walk
   #4) Move everything to the right place and see to right naming
   #5) continue with Fringe until satisfied, rename fringes so that they are referred to correctly
   #6) attachAndEval and rest of #agenda loop
   #7) can it possibly run?




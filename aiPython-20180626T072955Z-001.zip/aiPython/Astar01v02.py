print 'Hello Bent :D'
#planen var first at bare lage den selv, saa ikke saa pent kodet.
#det star #FIX: flere steder, det er der jeg
#med vilje ikke har brukt tid til at finne ut av syntax.
#koden kjorer derfor ikke, det er litt med vilje. kan du fikse fix? :D
#og saa har jeg vart lat og ikke lagt alt inn i klassen der det hoerer hjemme...
#beklager det og sant.
#Men jeg har kommentert en hel del masse, og der jeg ikke har folgt
#slavisk s 5 i supplement har jeg skrevet det. :)
#stor klem <3

class Walk:
   start = None #tuple, start node
   goal = None #tuple, goal node
   m = [] #node cost matrix
   myfile = None
   visual = [] #used to visualize what happened
   #found should be here
   #fringe should be here
   #closed should be here
   
   def __init__(self,filename):
      #reads file, initiates start,goal,m,visual
      self.myfile = filename
      fails=0
      row=0
      for line in open(filename):
         self.visual.append(line)
         thisrow = []
         for col,char in enumerate(line):
            if char == 'r':
               thisrow.append(1)
            elif char == 'g':
               thisrow.append(5)
            elif char == 'f':
               thisrow.append(10)
            elif char == 'm':
               thisrow.append(50)
            elif char == 'w':
               thisrow.append(100)
            elif char == '#':
               thisrow.append(999999)
            elif char == '.':
               thisrow.append(1)
            elif char == 'A':
               thisrow.append(0) #hvor mye skal det koste? Er det til eller fra?
               self.start=(row,col)
               #assume position cost is cost to go there
               #should never return to A in search
            elif char == 'B':
               thisrow.append(1) #hvor mye skal det koste? Er det til eller fra?
               self.goal=(row,col)
##            elif char == '\n':
##               print empty line
##            else:
##               fails = fails+1
##               print 'fails, because char is ', char, '. (row,col) is (', row, ',',col,')' 
         row = row + 1
         self.m.append(thisrow)
      return
   def myprint(self):
      for row in self.m:
         print row
      print 'visualized by'
      for row in self.visual:
         print row
   def val(self, mytuple):
      return self.m[mytuple[0]][mytuple[1]]
   ##tryBoard=Walk('board-2-3.txt')
   ##tryBoard.myprint()
      

class SearchNode:
    pos = None #tuple, same as 'state' in hand out
    g = None #cost to get to node
    n = None #cost of node
    h = None #maximal minimal value to get to goal
    f = None #g+n+h
    bestParent = None #FIX pointer to best parent: is it actually though,
    #the function is not made yet (attachAndEval). bestParent is used like pointer in propatatePathImprovement
    kids = None #list of all successor nodes
    isOpen = True #FIX: is this syntax right? open = True, or closed=false needed for visualisation
    def __init__(self, rowcol):
        self.pos = rowcol
    def h1 (self, goal):
       #the heuristic in the first part, distance.
       self.h= (abs(self.pos[0]-goal[0])+ abs(self.pos[1]-goal[1]))
       self.f = self.g+self.n+self.h
    def myprint(self):
       print '(',self.pos[0],',', self.pos[1], ')'
       
   ##x=SearchNode(2,4)
   ##y=SearchNode(5,6)
   ##print x.distance(y)
   ##found = {startNode.pos: startNode}
   ##print found[(0,0)].distance(x)

def generateAllSuccessors(searchNode):
   #return list of positions of legal successors
   #mark them as X'es kids
   #for walk game: up, down, left, right but not out of board
   #board is 40 columns and 10 rows
   #tuple (row number,col number) 
   if (searchNode[0]-1) >= 0:
      serchNode.kids.append((searchNode[0]-1, searchNode[1]))
   if (searchNode[0]+1) <= 9:
      serchNode.kids.append((searchNode[0]+1, searchNode[1]))
   if (searchNode[1]-1) >= 0:
      serchNode.kids.append((searchNode[0]  , searchNode[1]-1))
   if (searchNode[0]+1) >= 0:
      serchNode.kids.append((searchNode[0]  , searchNode[1]+1))
   return searchNode.kids
   
#load board from file
b = Walk('board-2-3.txt')
#initialize first node (n and pos), calculate g, h and f
startNode = SearchNode(b.start)
#print position of startnode
startNode.myprint()
#init startnode's g
startNode.g=0
#init startnode's n, h, f
startNode.n=b.val(startNode.pos)
startNode.h1(b.goal)

def propagatePathImprovement(parent):
   for c in parent.kids:
      child = found[c]
      #if the child benefits from switching bestParent
      if child.bestParent.g + child.n < child.g:
         child.bestParent = parent
         child.g = parent.g+child.n
         c.f = c.g+c.h
         #parents grandchildren might benefit from choosing child as bestParent
         propagatePathImprovement(child)



#initialize fringe(same as OPEN), closed and found (nodes not to generate)
found = {startNode.pos: startNode}
fringe = [startNode] #FIX: want to remove lowest valued element sorted from lowest to highest (ascending), want to be able to change values elements are sorted by
closed = [] #any order, don't revisit
     
#agenda loop
searching=True
while(searching):
   #nothing more to investigate
   if len(fringe)==0:
      break #return fail, but I don't know how this should be written
   #now consider lowest cost node (will make it CLOSED)
   x <- pop(fringe) #FIX: remove lowest from fringe, and work with it
   #mark x as being closed
   closed.append(x)
   x.isOpen==False
   
   #is X a solution?
   if x.pos==b.goal:
      #FIX: return X in a sensible way and end agenda loop
      serching=false
      print 'goal found, it\'s', x.pos
   succ <-generateAllSuccessors(x)
   for s in succ:
      #have already assigned them as kids in generateAllSuccessors
      #if new node
      if s not in found: #FIX: is this syntax right when found is dict, s is key?
         #find s
         #initiate pos,n,h,g,bestParent
         #generate f-value
         #resort fringe (OPEN)
         attachAndEval(s,x) #FIX: this func not made yet s a pos, x a node
      #if this is a better way to found node:
      elif x.g + found[s].n < found[s].g: #if this is a better path
         
         #update bestParent, g
         #update h?
         #update f
         #re-sort fringe (OPEN)
         attachAndEval(s,x) #FIX: this func not made yet s a pos, x a node
         #if the found node has children:
         if s in closed:
            #check if children want it as bestParent
            propagatePathImprovement(found[s])
         
         
#after agenda loop we have found the best path to the goal
#visualize by marking open and closed nodes
#then mark the path (know end node, everyone remembers their bestParent
#visualize
#document the code
#exercise A.1 and A.2 finished
#excercise A.3 compare with BFS and Dijkstra
#Do exercise A.4? 3 points sufficient to pass,
#can reuse most code, define new h function
         
   
   
   


    

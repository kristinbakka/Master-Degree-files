%mosjonist oppgave 2 a)
alder = 37:1:45; %x
lopetid = [45.54 41.38 42.5 38.8 41.26 37.2 38.19 38.05 37.45]; %y

beta = sum( (alder-sum(alder)/9).*lopetid)/ sum((alder-sum(alder)/9).^2);
alpha = (sum(lopetid) - beta*sum(alder))/9;

n = 100;
xalder = 36:(1/n):46;
yalder =alpha + beta*(xalder);

hold on
title('alpha = 75.96 min, beta = -0.88 min/�r');
plot(alder,lopetid,'+');
plot(xalder,yalder,'--');
xlabel('alder [�r]');
ylabel('tid [minutter]');

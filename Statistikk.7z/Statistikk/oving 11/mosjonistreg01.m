clc; close all; clear all;

% data set: Z
% generate the data set by oneself
n = 10000; % length of the data set
% mean and standard deviation
mu = 1;
sigma = 2;
Z = zeros(n,1);
for i = 1:n
    Z(i) = mu + sigma*randn;
end

% plot the histogram
x = (mu-5*sigma):0.1:(mu+5*sigma);
antall = hist(Z,x);
% Create standardized histogram: ar 0eal = 1
areal = sum(antall)*0.1;
figure
bar(x,antall/areal);
set(gcf,'Color',[1,1,1])
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hypothesis testing
% H0: mu = 1;
% H1: mu ~= 1;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hypothesis
mu_hypoth = 1;

% sample mean
Z_hat = mean(Z);

% sample standard devariance 
Z_std = std(Z);

% t-statistics - here we assume we don't know the true variance and thus 
% use the sample standard devariance, making it a t-test
t = abs((Z_hat - mu_hypoth))/(Z_std/sqrt(n));

% define the significance level
alpha = 0.05;

% reject H0 at significance level alpha when the computed t-statistic 
% exceed t(alpha/2,n-1) or less than -t(alpha/2,n-1)

% Probability of larger t-statistic
% note that student t distribtion is symmetric
p1 = 2*(1-tcdf(t,n-1)) 

% One could also use the building function in Matlab
% use help ttest to check the detail
[h,p2,ci] = ttest(Z,mu_hypoth,alpha)
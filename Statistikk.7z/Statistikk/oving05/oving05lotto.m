v = 1000; %antall vinnerrekker
vinnerrekke = zeros(1:7);
vinnmed34 = 0;

for rekke = 0 :v
    rekke
    i=1;
    while i <= 7
        vinnerrekke(i)= randi([1,34]);
        j = 1;     
        while j < i
            if vinnerrekke(i) == vinnerrekke(j)
                j=i ; %starter igjen med samme i
            else
                j=j+1;
            end
        end
    end
    
    for i = 1:7
        if vinnerrekke(i)== 34
            vinnmed34 = vinnmed34 +1
        end
    end            
    
    
    
end

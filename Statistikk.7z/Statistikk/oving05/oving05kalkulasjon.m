sum=0;
suma=1;

for x = 0:10
sumb = 0;
    suma = exp(-5)*5^x/factorial(x);
    for y = 0:(10-x)
        sumb = sumb + exp(-10)*10^y/factorial(y);
    end
    sum = sum + suma * sumb;
end
disp(sum);
clear
v = 1000 ;

lottotabell = draw_lottonumbers(7, 34,v);
N = v*7;
for i = 1 : N
    if lottotabell(i) ==34;
        lottotabell(i) =1;
    else
        lottotabell(i) = 0;
    end
end
ant34ere = sum(sum(lottotabell));
function [eyes,eyesum] = throw_dice(dices, throws, display)

% A function for throwing dices which returns frequency of single eyes and
% frequency of eyesum. 
% INPUT PARAMETERS
%   dices: # of dices to be thrown
%   throws: # of throws
%   display: 0 or 1, whether the function should plot histogram (1) or not (0)
% OUTPUT PARAMETERS
%   eyes: how many 1's, 2's,...,6's we have thrown in total
%   eyesum: how many times each possible eyesum has occured

eyes = zeros(6,2);
eyes(:,1) = 1:1:6; 

min_sum = 1*dices;
max_sum = 6*dices;

eyesum = zeros(max_sum-min_sum+1,2);
eyesum(:,1) = min_sum:1:max_sum;

for i=1:throws
   u = 6*rand(1,dices);
   temp_eyes = ceil(u);
   temp_sum = sum(temp_eyes);
   
   for j=1:dices
       eyes(temp_eyes(j),2) = eyes(temp_eyes(j),2)+1;
   end
   eyesum(temp_sum-min_sum+1,2) = eyesum(temp_sum-min_sum+1,2)+1;
end

if(display==1)
    disp('Eyes    Times')
    disp(eyes)

    disp('Eyesum    Times')
    disp(eyesum)
    
    subplot(1,2,1)
        bar(eyes(:,2));
        xlabel('Eyes');
    subplot(1,2,2)
        bar(eyesum(:,1),eyesum(:,2));
        xlabel('Eyesum');
    set(gcf,'Color',[1,1,1])    
end
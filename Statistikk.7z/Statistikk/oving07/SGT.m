disttool

%Normal

niutval=100;
AntallUtval=1000;
mu=5;
sigma=2;
for(i=1:AntallUtval)	
	utval=normrnd(mu,sigma, niutval,1);
	gjsnitt(i)=mean(utval);
end

figure
hold on
title('Fordelinga til gjennomsnittet, normalfordeling')
ylabel('antall')
hist(gjsnitt)
gjennomsnittNORMFORD = sum(gjsnitt)/AntallUtval; 


%Binomisk
figure
niutval=2;
AntallUtval=200;

N=5;
p=0.2;
for(i=1:AntallUtval)	
	utval=binornd(N,p, niutval,1);	
	gjsnitt(i)=mean(utval);
end
subplot(1,3,1);
	hist(gjsnitt(1:i));
    title('Fordelinga til gjennomsnittet, n = 2');
    ylabel('antall')
%---
niutval=5;
N=5;
p=0.2;
for(i=1:AntallUtval)	
	utval=binornd(N,p, niutval,1);	
	gjsnitt(i)=mean(utval);
end
subplot(1,3,2);
	hist(gjsnitt(1:i))
    title('Fordelinga til gjennomsnittet, n = 5');
    ylabel('antall')
%---
niutval=20;
N=5;
p=0.2;
for(i=1:AntallUtval)	
	utval=binornd(N,p, niutval,1);	
	gjsnitt(i)=mean(utval);
end
subplot(1,3,3);
	hist(gjsnitt(1:i));
    title('Fordelinga til gjennomsnittet, n = 20');
    ylabel('antall')

trondheim = load('trondheim.txt');
bodo = load('bodo.txt');
tynset = load('tynset.txt');

TRD = trondheim(:,6);
BO = bodo(:,6);
TY = tynset(:,6);

MT = [TRD BO TY];

%1) b)
        %Beskrivende analyse
        %2 plott/histogram for hvert datasett
        
        %plot
        subplot(3,2,1);
        hold on
        plot(TRD);
        title('Trondheim');
        xlabel('Dag');
        ylabel('Temperatur i Celcius');
        
        subplot(3,2,2);
        hist(TRD);
        title('Trondheim');
        xlabel('Ttemperatur i Celcius');
        ylabel('antall m�lepunkter');
        
        subplot(3,2,3);
        plot(BO);
        title('Bodo');
        xlabel('Dag');
        ylabel('Temperatur i Celcius');
        
        subplot(3,2,4);
        hist(BO);
        title('Bodo');
        xlabel('Temperatur i Celcius');
        ylabel('antall m�lepunkter');
        
        subplot(3,2,5);
        plot(TY);
        title('Tynset');
        xlabel('Dag');
        ylabel('Temperatur i Celcius');
        
        subplot(3,2,6);
        hist(TY);
        title('Tynset');
        xlabel('Temperatur i Celcius');
        ylabel('antall m�lepunkter');
        
        %histogram for h�nd: un�dvendig
       % p = 10; %antall s�yler
        %sorterer
       % TRDh = zeros(1,p);
       % TRDp =(max(TRD)-min(TRD))/p ;
       % minTRD = min(TRD);
        
       % for i = 1: length(TRD)
       %     a= TRD(i) - minTRD ;
       %     count = 0;
       %     while a >= 0 && count <10
       %         count = count + 1;
       %         a = a - TRDp;
       %     end
       %     TRDh(count) = TRDh(count) +1;
       % end
       % figure
       %bar(1:p,TRDh);
       %figure
       
                  
               
        %mean/median til hvert datasett. Forholdet er 1 for normalfordelt
        TRDfaktor = mean(TRD)/median(TRD);
        BOfaktor = mean(BO)/median(BO);
        TYfaktor = mean(TY)/median(TY);
        
        figure
        boxplot(MT);
        xlabel('1-Trondheim,        2-Bod�,       3-Tynset');
        ylabel('Temperatur i Celcius');
        
        figure
        subplot(3,1,1);
        normplot(TRD);
        title('Normal Probability Plot Trondheim');
        
        subplot(3,1,2);
        normplot(BO);
        title('Normal Probability Plot Bod�');
        
        subplot(3,1,3)
        normplot(TY);
        title('Normal Probability Plot Tynset');
        
        
        %scatterplot
        subplot(3,1,1);
        scatter(TRD,BO);
        title('Scatterplot TRD, BO');
        TRDcBO=corr(TRD,BO);
        
        subplot(3,1,2);
        scatter(TRD,TY);
        title('Scatterplot TRD, TY');
        TRDcTY=corr(TRD,TY);
        TYcTRD=corr(TY,TRD);
        
        subplot(3,1,3);
        scatter(TY,BO);
        title('Scatterplot TY, BO');
        TYcBO=corr(TY,BO);
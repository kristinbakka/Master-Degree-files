%OPPGAVE 1 c) Line�r regresjon

%trondheim(:,4)==23 er "Rad der det st�r 23 i kolonne 4"

t = trondheim(trondheim(:,4)==23,6);
Mnd = trondheim(trondheim(:,4)==23,3);
p = polyfit(Mnd(1:7),t(1:7),1);

plot(Mnd(1:7),t(1:7),'*',Mnd(1:7),polyval(p,Mnd(1:7),'-'));

xlabel('Mnd');
ylabel('Temperatur');
title('Trondheim');


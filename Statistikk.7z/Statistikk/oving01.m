%oppgavene til �ving 1 i statistikk v�ren 2014 av Kristin Bakka
format compact ;
%Forutsetter at disse er i samme mappe som matlabfilen. 
grunnkurs = load('tma42404245.txt') ;
trondheim = load('trondheim.txt') ;
bodo = load('bodo.txt') ;
tynset = load('tynset.txt') ;

%--------------------------------------
%--------------------------------------
%%OPPGAVE 1 


%--------------------------------------
%%OPPGAVE 1 a) Karakterfordeling statistikk

%I:       Variabler i datasettet tma42404245 som er kontinuerlige er strykpros
%jenteandel andelA, som er i intervalle fra 0 til 1, dvs 0 til 100%.
%Karakterfordelingen er diskret fordi de bare kan ta bestemte
%heltallsverdier mellom 0 (F er ikke regnet med, det er mulig at alle stryker) 
%og antall som tar faget.

%dataene for 2013:
v13 = grunnkurs(19,:) ;

%Karakterfordeling som g�r fra A til E i matrise y for 2013
hold on
y = grunnkurs(19,6:10) ;

%Jeg fikk problemer mex x, men tom label noen steder l�ste det. :)
x = {'';'A';'';'B';'';'C';'';'D';'';'E'} ; %Karakterene
bar(y) ; %plotter histogram
set(gca,'XTickLabel',x) ; %Instillinger
xlabel('Karakterer');
ylabel('Frekvens') ;
title('Oppgave 1: Histogram for TMA4245 V13') ;

%--------------------------------------

%%OPPGAVE 1 b)

%Vektorer med temperaturer for trondheim og bod�
ttemp = trondheim(:,6);
btemp = bodo(:,6) ;

%Gjennomsnittstemperaturene
tmitemp = mean(ttemp);
bmitemp = mean(btemp);

%medianverdien til temperaturen
tmetemp = median(ttemp);
bmetemp = median(btemp);



%I          Gjennomsnittsverdier blir mye forandret av ekstremverdier.
%Median blir reativt lite forandret av ekstremverdier gitt at det er liten
%forskjell p� de midterste verdiene i dataserien. Dette betyr at n�r
%gjennomsnittstemperaturen er noe h�yere enn medianen i bod�, er det minst
%en m�ling hvor temperaturen har v�rt mye h�yere enn hva som er tendensen i
%bod�.

%II         Hvis vi endrer en m�ling fra 4.5 til 450 f�r vi 
%[gjennomsnitt fra 6.9674 til 8.1879, og 
% median fra 5.6 til 5.7], som antatt. :) 

%III        max, min temperatur bod� 2013. Standardavvik og 
%varians til temperaturobservasjonene:
maxtempbodo = max(btemp) %skriver ut fordi dette ble spurt om. :)
mintempbodo = min(btemp) 
stdbodo = std(btemp)
varbodo = var(btemp)

%--------------------------------------
%OPPGAVE 1 c) Line�r regresjon

%trondheim(:,4)==23 er "Rad der det st�r 23 i kolonne 4"
t = trondheim(trondheim(:,4)==23,6);
Mnd = trondheim(trondheim(:,4)==23,3);
p = polyfit(Mnd(1:7),t(1:7),1);

figure
plot(Mnd(1:7),t(1:7),'*',Mnd(1:7),polyval(p,Mnd(1:7),'-'));

xlabel('Mnd');
ylabel('Temperatur');
title('OPPGAVE 1 c): Trondheim');

%--------------------------------------
%OPPGAVE 1 d) Variasjon
%Ut ifra plottet ser vi at variasjonen er st�rst i mai.

for i = 1:12
stdforMonth(i) = std(  trondheim(trondheim(:,3)==i,6)  );
end
%max(stdforMonth) i mnd 5 bekrefter dette. :)

%--------------------------------------
%--------------------------------------
%OPPGAVE 2

%--------------------------------------
%OPPGAVE 2 a)
v03 = grunnkurs(grunnkurs(:,1)==2003,6:10)
v13 = grunnkurs(19,6:10)
for i = 1:10
    if floor(i/2) == ceil (i/2)
        y2(i) = v13(i/2);
    else
        y2(i) = v03(i/2+.5);
    end
end
figure
x = {'A03';'A13';'B03';'B13';'C03';'C13';'D04';'D14';'E05';'E15'} ; %Karakterene
bar(y2) ; %plotter histogram
set(gca,'XTickLabel',x) ; %Instillinger
xlabel('Karakterer');
ylabel('Frekvens') ;
title('Oppgave 2a: Histogram for TMA4245 V03 og V13') ;

%--------------------------------------
%OPPGAVE 2 b)

t23bodo = bodo( bodo(:,4)==23 , 6) ;
%bruker mnd, som er lik for begge. :)
b = polyfit(Mnd,t23bodo,1) ;

figure
plot(Mnd(1:7),t(1:7),'*',Mnd(1:7),polyval(p,Mnd(1:7),'-'));

xlabel('Mnd');
ylabel('Temperatur');
title('OPPGAVE 2 b): Bod�');

%--------------------------------------
%OPPGAVE 2 c)

%Gjennomsnittstemperatur med standardavvik p� Tynset 2013, verdi har jeg
%skrevet i koden i etter uttrykket som regner det ut.

ttyn = tynset(:,6);
gjtynset = mean(ttyn) %4.9510
vartynset = var(ttyn) %128.5260
stdtynset = std(ttyn) %11.3369

gjtrd = mean(ttemp) %7.7732
vartrd = var(ttemp) %65.6103
stdtrd = std(ttemp) %8.1000

%Trondheim er kystklima, og siden havet har omtrent samme temperatur hele
%�ret burde temperaturen i l�pet av et �r i Trondheim ha lavere varianse 
%enn temperaturen i l�pet av et �r i Tynset, hvor det er innlandsklima.
%Det er ogs� dette vi observerer. :)

%--------------------------------------
%OPPGAVE 2 d)

for i = 1:730
    if floor(i/2) == ceil (i/2) %n�r vi har partallsplassering 
        y3(i) = ttyn(i/2);
    else
        y3(i) = ttemp(i/2+.5); %n�r vi har oddetallsplassering
    end
end

%Her skj�nte jeg ikke helt hva oppgaven spurte etter,s� jeg svarte p� to
%m�ter. F�rst plottet jeg observasjonene annen hever Tynset og Trondheim,
%og s� plottet jeg Trondheimobservasjonene f�st, og Tynsetobservasjonene
%etterp�. :)

figure
x = {''} ; %
bar(y3) ; %plotter histogram
set(gca,'XTickLabel',x) ; %Instillinger
xlabel('Temperaturdata for hhv Trondheim og Tynset for de samme datoene');
ylabel('Temperatur i grader Celsius') ;
title('Oppgave 2d: Histogram for Temperaturobservasjoner i Trondheim og Tynset i 2013') ;


y4 = [ttemp.' ttyn.'];
figure
x = {'Trondheim','','','','Tynset','','','',''} ; %
bar(ttemp) ; %plotter histogram
set(gca,'XTickLabel',x) ; %Instillinger
xlabel('Temperaturdata for hhv Trondheim og Tynset etter hverandre');
ylabel('Temperatur i grader Celsius') ;
title('Oppgave 2d: Histogram for Temperaturobservasjoner i Trondheim og Tynset i 2013') ;

% Beskriv histogrammene:
% Omr�der med positiv temperatur er omtrent like, men det m\blir mye
% kaldere p� Tynset, og blir senere varmt p� Tynset, og tidligere kaldt igjen. De h�yeste
% temperaturene m�les p� Tynset. :)



%--------------------------------------
%OPPGAVE 2 e)
figure
boxplot( tynset(:,6) , tynset(:,3) ) ;
xlabel('Mnd') ;
ylabel('Temperatur') ;
title('Oppgave 2 e) : Boksplot for temperaturobservasjoner i Tynset grupert etter m�ned')

for i = 1:12
    
stdTynMonth(i) = std( tynset( tynset(:,3)==i  ,  6      )  );
end
maxvariasjonmndTYN = max(stdTynMonth); % Og denne veriden finner vi igjen 
%i mnd 1, dvs at temperaturen varierer mest i mnd 1, januar, slik vi ogs�
%ser av plottet. :)

%--------------------------------------
%OPPGAVE 2 f)

figure
plot( ttemp , ttyn , '+' ) ;
xlabel('Temperatur i Trondheim') ;
ylabel('Temperatur i Tynset') ;
title('Oppgave 2 f) : Temperatur i Tynset mot temperatur i Trondheim i 2013')
% Temperaturen i Tynset og temperaturen i Trondheim viser omtrent
% rettlinjet avhengighet, og vi kan si at disse er avhengige.

figure
plot( ttemp , btemp , '+' ) ;
xlabel('Temperatur i Trondheim') ;
ylabel('Temperatur i Bod�') ;
title('Oppgave 2 f) : Temperatur i Bod� mot temperatur i Trondheim i 2013')

%Temperaturen i Bod� og i Trondheim viser omtrent rettlinjet avhengighet
%fra -5 celsius til +20 celsius. Utenfor dette omr�det virker det ikke p�
%samme m�ten, s� det avhengige plottet er Tynset vs Trondheim, og det
%uavhengige plottet er Bod� vs. Trondheim. :)

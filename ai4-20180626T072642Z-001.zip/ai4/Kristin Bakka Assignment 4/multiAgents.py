# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).
#NB0: autograder looks at #times GameState.generateSuccessor is called
#NB1: jeg har tolket possible actions= 0 som om dette er en win/loss state, fordi jeg tenker at pacman kan uansett velge at sta stille. Det kan vre de har implementert det som om Pacman ikke fr lov til at g p ghost, eller at et eller anne annet gr feil...
#NB2: jeg lar pacman/ghost choose first "best" action instead of doing a random of the best actions
#NB3: I say that first Pacman does something, then ghost 1, then ghost 2. Is this true, or do they do it all at once?
#NB4: How do you keep the Pacman window open?
#NB5: I call scoreEvaluationFunction(successorState) instead of something else we might have been supposed to use?

from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        return successorGameState.getScore()

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
#questions: 
#1 can I keep the searchTree in some way? Or new at each state?
#solved questions:
#how do I get #ghosts? gameState.getNumAgents()
TODO:
-any number of ghosts
-(1 min layer for each ghost) for every max layer
-expand graph tree to arbitrary depth (depth 2 gives pacman, ghost 1,..., ghost n each moves 1 time)
-minimax: go to bottom of tree

#1 Evaluate nodes at treeDepth depth*(#ghosts+1)

for d in 1:self.depth
    for j in #ghosts
	choose worst
    choose best

aka
chooseChild

-score leaves with self.evaluationFunction
-use self.depth, self.evaluationFunction (#timews used is important)

      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.
          Evaluated by number of calls to
          gameState.generateSuccessor(agentIndex, action):
        """
	
	currentDepth = 1
	currentAgent = 0
	
	myValue, myAction = self.minimaxEvaluation (gameState, currentDepth, currentAgent)
	return myAction
    
    
   
    def minimaxEvaluation (self, gameState, currentDepth, currentAgent):
         #returns (choiseValue, bestAction)
        if currentAgent == 0:
            bestValue = -float("inf") 
        else:
            bestValue = float("inf") 
       
        #for all possible choises
        for action in gameState.getLegalActions(currentAgent):
            successorState = gameState.generateSuccessor(currentAgent, action)
            #if successorstate is lossnode
            if not successorState.getLegalActions(0):
                value = scoreEvaluationFunction(successorState)
            #if next agent is ghost
            elif currentAgent + 1 < gameState.getNumAgents() :
                value, temp = self.minimaxEvaluation(successorState, currentDepth, currentAgent +1)
            #next is leafnode because max number of actions reached
            elif currentDepth == self.depth:
                value = scoreEvaluationFunction(successorState)
            #next agent pacman
            else:
                value, temp = self.minimaxEvaluation(successorState, currentDepth + 1, 0)
            #Is this action better? Save it.
            #Better for Pacman
            if currentAgent == 0:
                if value > bestValue:
                    bestValue = value
                    bestAction = action
            #Better for Ghost
            else:
                if value < bestValue:
                    bestValue = value
                    bestAction = action
        return (bestValue, bestAction)

         

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Want to write:
          python autograder.py -q q3
          and get the same as
          python autograder.py -q q2
          
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        currentDepth = 1
	currentAgent = 0
	
	myValue, myAction = self.alphabetaEvaluation(gameState, currentDepth, currentAgent, -float("inf"),float("inf"))
	return myAction

    def alphabetaEvaluation (self, gameState, currentDepth, currentAgent, alpha, beta):
        #Initialize value
        if currentAgent == 0:
            bestValue = -float("inf")
        #Ghost
        else:
            bestValue = float("inf")

        for action in gameState.getLegalActions(currentAgent):
            #Relationship with Children:
            successorState = gameState.generateSuccessor(currentAgent, action)
            #game is over
            if not successorState.getLegalActions(0):
                value = scoreEvaluationFunction(successorState)
            #next is leafnode because max number of actions reached
            elif (currentAgent + 1 == gameState.getNumAgents()) and(currentDepth == self.depth):
                value = scoreEvaluationFunction(successorState)
            #Next depth (next is pacman)
            elif currentAgent + 1 == gameState.getNumAgents():
                value, temp = self.alphabetaEvaluation(successorState, currentDepth + 1, 0, alpha, beta)
            #Next agent (next is ghost)
            else :
                value, temp = self.alphabetaEvaluation(successorState, currentDepth, currentAgent + 1, alpha, beta)

            #Relationship with Parents:
            #when current is Pacman
            if currentAgent == 0:
                #NB Not equal to, else autograder collapses
                #is this higher (better) than worstSiblingValue (alternative best)
                if value > beta:
                    #returns due to pruning
                    return (value, action)
                #is this better than best yet
                if value > bestValue:
                    bestValue = value
                    bestAction =  action
                    if value > alpha :
                        alpha = value
            #when current is Ghost
            else : 
                #NB Not equal to, else autograder collapses
                if value < alpha:
                    #returns due to pruning
                    return (value, action)
                #is this better than best yet
                if value < bestValue:
                    bestValue = value
                    bestAction = action
                    if value < beta :
                        beta = value
        return (bestValue, bestAction)





class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction


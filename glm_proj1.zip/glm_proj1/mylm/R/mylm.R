
# Select Build, Build and reload to build and loade into the R-session.

mylm <- function(formula, data = list(), contrasts = NULL){
  # Extract model matrix & responses
  mf <- model.frame(formula = formula, data = data)
  x  <- model.matrix(attr(mf, "terms"), data = mf, contrasts.arg = contrasts)
  y  <- model.response(mf)
  terms <- attr(mf, "terms")

  ## TERMS USED LATER
  # Total number of data
  n <- dim(x)[1]
  # Number of parameters
  p <- dim(x)[2]
  # Inverse matrix used for bla covariance
  cij <- solve(t(x)%*%x)
  # Hat matrix H = x (t(x) x)^(-1) t(x)
  H <- x%*%cij%*%t(x)

  # yhat=x beta + residuals
  yhat <- H%*%y
  residuals <- y - yhat
  # Sum of Squared Errors
  sse <- as.numeric(t(residuals)%*%residuals)
  # Sum of Squares Total
  sst <- sum((y-mean(y))^2)
  # Residual Sum of Squares
  sigmahat <- as.numeric(sqrt(sse/(n-p)))


  # Tests
  std.err <- sigmahat*sqrt(diag(cij))

  ## STORE LIST est OF RETURNED PARAMETERS
  est <- list(terms = terms, model = mf)

  # Call and formula used
  est$call <- match.call()
  est$formula <- formula

  # Fitted values and residuals
  est$residuals <- residuals[1:length(y)]
  est$fitted.values <- yhat
  est$sse <- sse

  # Store other basic properties
  est$df <- n-p #3981
  est$n <-n
  est$p <-p
  est$y <-y
  est$x <-x

  # beta
  est$coefficients <- cij%*%t(x)%*%y
  est$covMatrix=sigmahat^2*cij
  est$beta.std.err = sqrt(diag(sigmahat^2*cij))

  # Tests
  est$Rsquared <- 1-sse/sst
  est$res.std.err<-sigmahat

  # Chi-squared test
  sse_mod0<- as.numeric(t(y-mean(y))%*%(y-mean(y)))
  Xvalue= (n-p)*(sse_mod0/sse-1)
  temp3=pchisq(q=Xvalue,df=p-1,lower.tail = FALSE)

  # Store Chi-squared test
  est$PrX=ifelse(temp3<2e-16,"<2e-16",temp3)
  est$Xvalue=Xvalue

  # Set class name. This is very important!
  class(est) <- 'mylm'
  # Return the object with all results
  return(est)
}

print.mylm <- function(object, ...){
  # Code here is used when print(object) is used on objects of class "mylm"
  # Useful functions include cat, print.default and format
  cat('print.mylm()\nCall:\n')
  print(object$call)
  cat("\n Coefficients:\n")
  names <- row.names(object$coefficients)
  pp <- matrix(NA,2,length(names))
  pp[1,] <- names
  pp[2,] <- object$coefficients
  print(object$coefficients)
  cat("\n")
}

summary.mylm <- function(object, ...){
  # Code here is used when summary(object) is used on objects of class "mylm"
  # Useful functions include cat, print.default and format
  cat('summary.mylm()\nCall:\n')
  print(object$call)
  cat("\n Residuals:\n")

  #Summary of residuals, could be accomplised by
  # sort(object$residuals)[c(1,round(0.25*n),
  #   round(0.50*n),round(0.75*n),n)]
  print(summary(object$residuals))

  cat("\n Coefficients: \n")
  z <- (object$coefficients)/(object$beta.std.err)
  pz <- 2*pnorm(abs(z),lower.tail=FALSE)

  symbols <- array("",length(pz))
  symbols[which(pz<0.1)]<-"."
  symbols[which(pz<0.05)]<-"*"
  symbols[which(pz<0.01)]<-"**"
  symbols[which(pz<0.001)]<-"***"

  #construct data frame for printing
  summ <- data.frame(object$coefficients,object$beta.std.err,z,pz,symbols)
  names(summ)<-c("Estimate","Std.Error","z value","Pr(>|z|)","")
  summ <- format.data.frame(summ,digits=3)
  summ$`Pr(>|z|)`[which(pz<2e-16)] <- "<2e-16"
  print(summ)

  cat("---\n Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1\n\n")

  cat("Residual standard error: ",format(object$res.std.err,digits=3), "on", format(object$df,digits=4),
"degrees of freedom\nMultiple R-squared:",  format(object$Rsquared,digits=4),
"Adjusted R-squared:",format(1-(1-object$Rsquared)*(object$n-1)/(object$n-object$p-1),digits=4), "\nX-statistic:",
format(object$Xvalue,digits=4), "on", object$p-1, "DF,  p-value:",object$PrX)
}

plot.mylm <- function(object,p1=TRUE,p2=TRUE,p3=TRUE,p4=TRUE, ...){
  # Code here is used when plot(object) is used on objects of class "mylm"
  # returns 4 plots (when set to true):
  # 1) Residuals vs Fitted
  # 2) Normal Q-Q
  # 3) Scale-Location
  # 4) Residuals vs Leverage

  library(ggplot2)
  if(p1){
  # ggplot requires that the data is in a data.frame, this must be done here
  data <- data.frame(fitted.values=object$fitted.values,residuals=object$residuals)
  gg1 <- ggplot(data = data,aes(x=fitted.values,y=residuals))
  gg1 <- gg1 + geom_point(pch = 21) + geom_hline(yintercept = 0, linetype = "dashed") +
    geom_smooth(se = FALSE, col = "red", size = 0.5, method = "loess")
  gg1<- gg1+  labs(x = "Fitted values", y = "Residuals", title = "Residuals vs Fitted values", subtitle = deparse(object$call))
  plot(gg1)


  #2)
  qqdata <- data.frame(zq=qnorm(1:object$n/(object$n+1)), y_ord=(sort(object$y)-mean(object$y))/object$res.std.err)
  gg2 <- ggplot(qqdata, aes(x=zq,y=y_ord))

  gg2<-gg2+ geom_point(pch = 21) +
    geom_abline(intercept = 0, slope = 1, linetype = "dotted") +
    labs(x = "Theoretical quantiles", y = "Standardized residuals", title = "Normal Q-Q", subtitle = deparse(object$call))

  plot(gg2)
  }


  # if you want the plot to look nice, you can e.g. use "labs" to add labels, and add colors in the geom_point-function

}

anova.mylm <- function(object, ...){
  cat('anova.mylm()\n')
  # Code here is used when anova(object) is used on objects of class "mylm"

  # Components to test
  comp <- attr(object$terms, "term.labels")
  k = length(comp)

  # Name of response
  response <- deparse(object$terms[[2]])

  # Fit the sequence of models
  txtFormula <- paste(response, "~", sep = "")
  model <- list()
  for(numComp in 1:k){
    if(numComp == 1){
      txtFormula <- paste(txtFormula, comp[numComp])
    }
    else{
      txtFormula <- paste(txtFormula, comp[numComp], sep = "+")
    }
    formula <- formula(txtFormula)
    model[[numComp]] <- mylm(formula = formula, data = object$model)
  }
  #Start of own code
  txtFormula <- paste(response, "~", sep = "")
  txtFormula <- paste(txtFormula, 1)
  model_0 <- mylm(formula = formula(txtFormula), data = object$model)

  sse=rep(NA,k+1)
  df=rep(NA,k+1)
  #sse for only intercept
  sse[1]=model_0$sse
  df[1]=model_0$df
  for(i in 1:k){
    sse[i+1]=model[[i]]$sse
    df[i+1]=model[[i]]$df
  }


  # Print Analysis of Variance Table
  Df    =rep(NA,k)
  SumSq =rep(NA,k)
  Xvalue=rep(NA,k)
  PrX   =rep(NA,k)

  for(i in 2:(k+1)){
    Df[i-1]=df[i-1]-df[i]
    SumSq[i-1]=sse[i-1]-sse[i]
    Xvalue[i-1]=df[k+1]*(sse[i-1]-sse[i])/(sse[k+1])
    PrX[i-1]=pchisq(q=Xvalue[i-1],df=Df[i-1],lower.tail = FALSE)
  }

  #Printing and printing symbols
  symbols <- array("",length(PrX))
  symbols[which(PrX<0.1)]<-"."
  symbols[which(PrX<0.05)]<-"*"
  symbols[which(PrX<0.01)]<-"**"
  symbols[which(PrX<0.001)]<-"***"
  PrX[which(PrX<2e-16)] <- "<2e-16"


  cat('Analysis of Variance Table\n')
  cat(c('Response: ', response, '\n'), sep = '')
  cat('          Df    Sum sq X2 value Pr(>X2)\n')

  for(i in 1:k){
    cat(format(x=comp[i],width=10),'')
    #spaces = rep(x=' ', times=round(10-nchar(comp[i],type = "width"))/2)
    #cat(spaces)
    cat(c(Df[i], "   ", #df
          format(x=SumSq[i],digits=5,width=5),#sum sq
          format(x=Xvalue[i],width=8), #Chi-value
          format(x=PrX[i],digits =6),
          symbols[i],"\n")) #p-value
  }
  cat(c('Residuals',format(x=df[k+1],widt=5), format(x=sse[k+1],digits=6)))
  cat("\n---\n Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1\n\n")
  return(model)

}

#run_package_v01
#library(rtools) I don't think this is the kind of package we load
#into Rstudio, as it is for building (restart session after build)

#set working directory and load data
library(mylm)
setwd("C:/Users/Kristin/Documents/h17_fag/GLM/comp_exc_01")
library(car)
data(SLID, package = "car")
SLID <- SLID[complete.cases(SLID), ]
library("GGally")
library("ggplot2")

#--------------
if(FALSE){ggpairs(SLID)}

#This is yield from full lm object
lm_obj=lm(wages~education + age + sex + language, data = SLID)
lm_obj
print(lm_obj)
summary(lm_obj)
anova(lm_obj)

#This is yield from my own object
mylm_obj=mylm(wages~education + age + sex + language, data = SLID)
mylm_obj
print(mylm_obj)
summary(mylm_obj)
anova(mylm_obj)

#while working on anova, use
object=mylm_obj
object=model5b

#while working on mylm use
formula=wages~education + age + sex + language
data=SLID

# While working with reduced model
formula=wages~education

# While working with model2
model2ea <- mylm(wages ~ education + age, data = SLID)
model2ae <- mylm(wages ~ age + education, data = SLID)

lm_model2ea <- lm(wages ~ education + age, data = SLID)
lm_model2ae <- lm(wages ~ age + education, data = SLID)

# Fix ANOVE to use mean sq? is language included at some point?


# While working on ggplot use
library(ggplot2)
# ggplot requires that the data is in a data.frame, this must be done here
data <- data.frame(fitted.values=object$fitted.values,residuals=object$residuals)
gg <- ggplot(data = data,aes(x=fitted.values,y=residuals))
gg <- gg + geom_point(pch = 21) + geom_hline(yintercept = 0, linetype = "dashed") +
  geom_smooth(se = FALSE, col = "red", size = 0.5, method = "loess")
gg<- gg+  labs(x = "Fitted values", y = "Residuals", title = "Residuals vs Fitted values", subtitle = deparse(object$call))
gg



library(ggplot2)
xvec=c(0,1,4,5,2,6,7,8,9)
yvec=c(3,7,6,4,4,5,2,7,9)
# ggplot requires that the data is in a data.frame, this must be done here
xydata <- data.frame(fitw=xvec,resid=yvec)
xg <- ggplot(data = xydata,aes(x=fitw,y=resid))
xg <- xg + geom_point()
xg

#testing gg-plot
library(ggplot2)
# Basic scatter plot
ggplot(mtcars, aes(x=wt, y=mpg)) + geom_point()
# Change the point size, and shape
ggplot(mtcars, aes(x=wt, y=mpg)) +
  geom_point(size=2, shape=23)


##########################################
# Trying to plot the residual plot thingy
ggplot(data = data, aes(x = "Fitted values", y = "Residuals")) + geom_point(pch = 21) + geom_hline(yintercept = 0,
linetype = "dashed") + geom_smooth(se = FALSE, col = "red", size = 0.5,
method = "loess") + labs(title = "Residuals vs Fitted values",
subtitle = deparse(mylm_obj$call))
#############

library(knitr)
purl("https://www.math.ntnu.no/emner/TMA4315/2017h/1Intro.Rmd")

#---------
x_min=min(SLID$age)
x_max=max(SLID$age)
b=model4b$coefficients
p <- ggplot(data = data.frame(x = 0), mapping = aes(x = x))
fun.male <- function(x) x*(b[3]-b[4])+b[1]-b[2]
fun.fem  <- function(x) x*(b[3]+b[4])+b[1]+b[2]
p<-p+ stat_function(fun = fun.male,col="blue")
p<-p+ stat_function(fun = fun.fem ,col="red")
p<-p+ xlim(x_min,x_max)
p<-p+ labs(x = "Age", y = "E(Wage)", title = "Expected value of wage vs Age", subtitle = "Women (on the bottom) in red and men in black.")
p

data <- data.frame(fitted.values=object$fitted.values,residuals=object$residuals)
gg <- ggplot(data = data,aes(x=fitted.values,y=residuals))

#--------
# Make some noisily increasing data
plotdat <- data.frame(cond = ifelse(model4a$x[,2]==1,"M","F"),
                  xvar = model4a$x[,3],
                  yvar = model4a$y)
head(plotdat)
ggplot(plotdat, aes(x=xvar, y=yvar, color=cond)) +
  geom_point(shape=1) +
  scale_colour_hue(l=50) + # Use a slightly darker palette than normal
  geom_smooth(method=lm,   # Add linear regression lines
              se=TRUE)    # Don't add shaded confidence region

#-------
set.seed(955)
# Make some noisily increasing data
dat <- data.frame(cond = rep(c("A", "B"), length.out=20),
                  xvar = 1:20 + rnorm(20,sd=3),
                  yvar = 1:20 + rnorm(20,sd=3))
head(dat)
ggplot(dat, aes(x=xvar, y=yvar, color=cond)) +
  geom_point(shape=1) +
  scale_colour_hue(l=50) + # Use a slightly darker palette than normal
  geom_smooth(method=lm,   # Add linear regression lines
              se=FALSE)    # Don't add shaded confidence region
#-------

#ARMA(1,2)
phi <- c(-0.8)

theta <- c(1.88,-0.98)
par(mfcol=c(4,1)) #Figuroppsett
ARroot= (polyroot(c(1,-phi))) #fordi -phi_1 etc
MAroots = (polyroot(c(1,-theta))) #fordi -theta_1 etc, ingrasing order of B's
#do something with roots, i.e. plot

Z <- arima.sim(model = list(ar=phi,ma=-theta), n=1000) #parameterisert annerledes enn Weib
plot(Z,xlim=c(0,100))
acf(Z)
points(0:30,ARMAacf(ar=phi,ma=-theta,lag.max=30), col="red")
pacf(Z)
points(1:30,ARMAacf(ar=phi,ma=-theta,lag.max=30, pacf = TRUE), col="red")

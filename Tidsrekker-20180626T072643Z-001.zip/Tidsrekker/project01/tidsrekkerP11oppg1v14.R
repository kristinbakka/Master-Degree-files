#mine:
acf2pacf <- function(rhoVec)  {
  nextPhiVec = rep(NA,length(rhoVec))
  pacfVec = rep(NA, length(rhoVec))
  pacfVec[1] = rhoVec[1]
  phiVec = pacfVec
  vk = 35.29177777778*(1-(pacfVec[1])^2)
  for (k in 1:(length(rhoVec)-1)){
    sum1=0
    sum2=0
    for (j in 1:k){ #kloop
      sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
      sum2 = sum2 + phiVec[j]*rhoVec[j]
    }
    pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    nextPhiVec[k+1]=pacfVec[k+1]
    vk[k+1] = vk[k]*(1-(pacfVec[k+1])^2)
    for (j in 1:k){ #For j in 1:k
      nextPhiVec[j] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
    }
    phiVec = nextPhiVec
  }
  return(list("weights"=phiVec,"variance"=vk, "pacf"=pacfVec))
}

#Generate rho vector of rho_1 to rho_k for our model
rhok <- function(k) {
  phi = -0.8
  theta = c(1.88, -0.98)
  gamma0 = (1/(1-phi^2))*(1-2*phi*theta[1]-2*phi*theta[2]*(phi-theta[1])+(theta[1])^2+(theta[2])^2)
  rho = phi - (theta[1] + phi * theta[2] - theta[1] * theta[2]) * 1 /gamma0
  
  if (k == 1){return (rho)}
  rho[2] = phi * rho[1] - theta[2]/gamma0
  if (k == 2){return (rho)}
  for (j in 3:k) {
    rho[j] = phi * rho[j-1]
  }
  return (rho)
}

myRoots<- function(k) {
  phi = -0.8
  theta = c(1.88, -0.98)
  Broots = (polyroot(c(1,-theta))) #fordi -theta_1 etc, ingrasing order of B's
  revRoots = c(1/Broots[1],1/Broots[2])
  return(list("alpha"=Mod(revRoots[1]),"lambda"=abs(Arg(revRoots[1])),"rootSize"=Mod(Broots[1]),"rootAngle"=Arg(Broots[1])))
}

myExpon <- function(vi, i, vj, j, alpha) {
  #c*alpha^x + d
  vj=vi
  j=i
  
  c = (vj)/(alpha^(j-1))
  #d= vi - alpha^i*c
  d=vj-alpha^j
  return(list("c"=c,"alpha"=alpha, "d"=d))
}

myArma <- function(observations){
  rho = rhok(observations)
  #generate partial acf's, weights, forecast variance vector
  acf2pacf = acf2pacf(rho)
  myRoots = myRoots(observations)
  i=17
  j=38
  myExpon=myExpon(acf2pacf$pacf[i],i,acf2pacf$pacf[j],j,myRoots$alpha)
  
  return(list("length"=observations, "rho"=rho, "pacf"=acf2pacf$pacf, "weights"=acf2pacf$weights,"variance"=acf2pacf$variance, 
              "lambda"=myRoots$lambda, "period"=2*pi/myRoots$lambda, "c"=myExpon$c, "d"= myExpon$d, "alpha"=myRoots$alpha))
}

myPacfPlot <- function(observations){
}

#how many observations do we want
observations = 80
#myPacfPlot(obs)
#generate model
m = myArma(observations)
#x'es
x=seq(1,m$length,1)
#plot the partial acfs
plot(x=x,y=m$pacf,xlab = "lag j", ylab = "pacf",type="p")
#0-line
lines.default(x=x,y=rep(0,m$length))
#exponential decayumm... why is it not exponential?
lines(x=x, y=  m$alpha^(x-1) * m$c ,col="red")
lines(x=x, y= -m$alpha^(x-1) * m$c ,col="red")



#ARMA(2,2)
phi <- c(1.5,-.6)

theta <- c(.1,-.9)
par(mfcol=c(3,1)) #hva er dette? Figuroppseett?
ARroots= (polyroot(c(1,-phi))) #fordi -phi_1 etc
MAroots = (polyroot(c(1,-theta))) #fordi -theta_1 etc, ingrasing order of B's

Z <- arima.sim(model = list(ar=phi,ma=-theta), n=1000) #parameterisert annerledes enn Weib
plot(Z,xlim=c(0,100))
acf(Z)
points(0:30,ARMAacf(ar=phi,ma=-theta,lag.max=30), col="red")
pacf(Z)
points(1:30,ARMAacf(ar=phi,ma=-theta,lag.max=30, pacf = TRUE), col="red")

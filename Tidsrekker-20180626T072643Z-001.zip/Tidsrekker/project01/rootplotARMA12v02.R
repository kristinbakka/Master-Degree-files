#ARMA(1,2)
phi <- c(-0.8)

theta <- c(1.88,-0.98)
par(mfcol=c(7,1)) #Figuroppsett
ARroot= (polyroot(c(1,-phi))) #fordi -phi_1 etc

Broots = (polyroot(c(1,-theta))) #fordi -theta_1 etc, ingrasing order of B's

BvAlpha = Mod(Broots[1])
BAngle= Arg(Broots[1])

revRoots = c(1/Broots[1],1/Broots[2])
revAlpha = Mod(revRoots[1])
revAngle= Arg(revRoots[1])
#do something with roots, i.e. plot

Z <- arima.sim(model = list(ar=phi,ma=-theta), n=1000) #parameterisert annerledes enn Weib
plot(Z,xlim=c(0,100))
acf(Z)
points(0:30,ARMAacf(ar=phi,ma=-theta,lag.max=30), col="red")
pacf(Z)
points(1:30,ARMAacf(ar=phi,ma=-theta,lag.max=30, pacf = TRUE), col="red")

#if error check
#par("mar")
#if problem then
#par(mar=c(1,1,1,1))
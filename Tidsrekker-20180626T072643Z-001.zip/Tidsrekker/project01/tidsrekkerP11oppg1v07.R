#mine:
rhoToPACF <- function(rhoVec, regCoefs=FALSE)  {
  #hardcoded for our problem
  vk = 35.29177777778
  
  nextPhiVec = rep(NA,length(rhoVec))
  pacfVec = rep(NA, length(rhoVec))

  pacfVec[1] = rhoVec[1]
  phiVec = pacfVec

  for (k in 1:(length(rhoVec)-1)){
    sum1=0
    sum2=0
    
    for (j in 1:k){ #kloop
      sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
      sum2 = sum2 + phiVec[j]*rhoVec[j]
    }
    pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    nextPhiVec[k+1]=pacfVec[k+1]
    vk = vk(1-pacfVec[k+1])
  
    for (j in 1:k){ #For j in 1:k
      nextPhiVec[j] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
    }
    phiVec = nextPhiVec
  }
  if(regCoefs){
    return(list("weights"=pacfVec,"variance"=vk))
  }
  return(pacfVec)
}
#his (does exactly the same):
acf2pacf <- function(rho,forecast=FALSE) {
  k.max <- length(rho)
  phi <- matrix(0, k.max,k.max)
  phi[1,1] = rho[1]
  for (k in 1:(k.max-1)) { #kloop
    jj <- 1:k #For j in 1:k
    phi[k+1,k+1] <- (rho[k+1]- sum(phi[k,jj]*rho[k+1-jj]))/(1-sum(phi[k,jj]*rho[jj]))
    phi[k+1,jj] <- phi[k,jj] - phi[k+1,k+1]*phi[k,k+1-jj]
  }
  if(regression){
    vk = 35.29177777778*(1-sum(phi[k,jj]*rho[jj]))
    return (list("weights"=diag(phi),"variance"=vk))
  }
  return(diag(phi))
}

#Generate rho vector of rho_1 to rho_k for our model
rhok <- function(k) {
  phi = -0.8
  theta = c(1.88, -0.98)
  #??2a1?????21[1???2??1??1???2??1??2(??1?????1) +??21+??2
  gamma0 = (1/(1-phi^2))*(1-2*phi*theta[1]-2*phi*theta[2]*(phi-theta[1])+(theta[1])^2+(theta[2])^2)
  #gamma[1] = phi_1 * gamma_0 - (theta_1 + phi_1 * theta_2 - theta_1 * theta_2) * sigma_a^2
  #rho[1] = gamma[1]/gamma[0] = phi_1 * rho_0 - (theta_1 + phi_1 * theta_2 - theta_1 * theta_2) * sigma_a^2/gamma0   
  rho = phi - (theta[1] + phi * theta[2] - theta[1] * theta[2]) * 1 /gamma0
  
  if (k == 1){return (rho)}
  
  #gamma[2] = phi_1 * gamma_1 - theta_2 * sigma_a^2
  #rho[2] = phi_1 * rho_1 - theta_2 * sigma_a^2/gamma_0
  rho[2] = phi * rho[1] - theta[2]/gamma0
  
  if (k == 2){return (rho)}
  

  for (j in 3:k) {
    #gamma_k = phi_1 * gamma[k-1]
    rho[j] = phi * rho[j-1]
  }
  return (rho)
}
#gamma_0 = ??1??1+ (1?????1??1+??21+??1??1??2+??22?????21??2)??2
#gamma_0 = phi_1 * ??1+ (1?????1??1+??21+??1??1??2+??22?????21??2)??2

generatePACF<- function(rhoVec){

  #generates the pacfs from lag 1 to lag k (length of rho)
  pacfk = rhoVec[1]
  if(length(rhoVec)==1){
    return (pacfk)
  }
  for (k in 2:length(rhoVec)){
    #this is ugly code, please don't show it to anyone:
    temp <- rhoToPACF(rhoVec)
    pacfk[k] = temp[k]
  }
  return (pacfk)
}

#NB: rho zero not included in the vector, this is for k lags
k=30
rhovector = rhok(k)
#pacf for same number of lags as the rhovec has
mpacf = generatePACF(rhovector)

plot(c(1:k), mpacf)


#plan:
#1. ta inn vektor med k elementer
#2. lag matrisen som skal være under brøkstrek
#3. lag matrisen som skal være over (bytt ut siste kolonne)
#4. ta determinanter og del på, ferdig
#plan 1 benytter ...
#ny plan, plan 2
#matrisen i pkt 2 (og nesten3) er en Toeplitz matrise, løses ved Durbin-Levinson
#plan 2 benytter (2.3.18) side 12 i boka
#so gir rho vector = rho Toeplitz matrix * unknown vector
#rho vector[rho_1 ... rho_k] = [rho_0 ... rho_k-1; rho_1 rho_0 rho_1 rho_2 ... rho__k-2; ... ; rho_k-1 rho_k-2 ... rho_0] * [phi_k1; phi_k2; ... phi_kk]
#only want phi_kk
#why don't we just use the formula for phi_kk, or simply solve?
#do we have to explain all the way from (2.3.2) to (2.3.18)? Quite unintelligable
#
#Algorithm
#1. ta inn vektor innvector med k elementer
#2. toeplitz(vector[innvector med pushback tallet 1 plassert forrerst, rho_k faller ut])
#Durbin to solve 
#return phi_kk

x <- 1:5
toeplitz (x)

phiToPACF <- function(rhovector)  {
# takes in a vector of rho_1, rho_2, ..., rho_k, returns phi_k1, phi_k2, ..., phi_kk,
# uses Durbin-Levinson iteration
  k=length(rhovector)
  rhomatrix = toeplitz(c(1,rhovector[1:k-1]))
# rhovector = rhomatrix * find 
  phivector = solve(rhomatrix,rhovector) #exchange this step with
  phialternative = levinson(c(1,rhovector))
  return(phivector[k])
}

rhovector = 2:6
#??? I should Of course try to run it with the data
#try to run it:
myvec = phiToPACF(rhovector)




#-------
y=c(rhovector[1:3])

z=c(1,rhovector[1:-1])

#------

rhoVec = 4:20
nextPhiVec = rep(NA,length(rhoVec))
pacfVec = rep(NA, length(rhoVec))

pacfVec[1] = rhoVec[1]
phiVec = pacfVec

for (k in 1:length(rhoVec)){
  sum1=0
  sum2=0
# A
  for (j in 1:k-1){
    sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
    sum2 = sum2 + phiVec[j]*rhoVec[j]
  }
  pacfVec[k+1]=(rhovector[k+1]-sum1)/(1-sum2)
  nextPhiVec[k+1]=pacfVec[k+1]
  
# B
  for (j in 1:k){
    nextPhiVec[k] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
  }
  phiVec = nextPhiVec[k]
}






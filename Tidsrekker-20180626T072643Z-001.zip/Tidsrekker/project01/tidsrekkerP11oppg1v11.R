#mine:
rhoToPACF <- function(rhoVec, regCoefs=FALSE)  {
  #returns the pacfs of lag 1 to k=length(rhovec) when regCoefs=FALSE
  #optionaly returns the weights of lag 1 to k=length(rhovec), and the variance 
  #hardcoded for our problem
  vk = 35.29177777778
  
  nextPhiVec = rep(NA,length(rhoVec))
  pacfVec = rep(NA, length(rhoVec))
  pacfVec[1] = rhoVec[1]
  phiVec = pacfVec

  for (k in 1:(length(rhoVec)-1)){
    sum1=0
    sum2=0
    
    for (j in 1:k){ #kloop
      sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
      sum2 = sum2 + phiVec[j]*rhoVec[j]
    }
    #I used these, page 2: http://www.pstat.ucsb.edu/faculty/feldman/174-03/lectures/l13
    pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    nextPhiVec[k+1]=pacfVec[k+1]
    vk = vk*(1-(pacfVec[k+1])^2)
  
    for (j in 1:k){ #For j in 1:k
      nextPhiVec[j] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
    }
    phiVec = nextPhiVec
  }
  if(regCoefs){
    #I found this expression by reverse engineering
    #my code:       pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    #lecture notes: pacfVec[k+1]=(rhoVec[k+1]-sum1)*gamma0/variance
    #variance = gamma0(1-sum2)
    variance = 35.29177777778*(1-sum2)
    return(list("weights"=phiVec,"variance"=vk, "altVar"=variance))
  }
  return(pacfVec)
}
#his (does exactly the same):
acf2pacf <- function(rho,forecast=FALSE) {
  k.max <- length(rho)
  phi <- matrix(0, k.max,k.max)
  phi[1,1] = rho[1]
  for (k in 1:(k.max-1)) { #kloop
    jj <- 1:k #For j in 1:k
    phi[k+1,k+1] <- (rho[k+1]- sum(phi[k,jj]*rho[k+1-jj]))/(1-sum(phi[k,jj]*rho[jj]))
    phi[k+1,jj] <- phi[k,jj] - phi[k+1,k+1]*phi[k,k+1-jj]
  }
  if(regression){
    #I found this expression by reverse engineering
    #my code:       pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    #lecture notes: pacfVec[k+1]=(rhoVec[k+1]-sum1)*gamma0/variance
    #variance = gamma0(1-sum2)
    vk = 35.29177777778*(1-sum(phi[k,jj]*rho[jj])) #approx 1.077
    return (list("weights"=diag(phi),"variance"=vk))
  }
  return(diag(phi))
}

#Generate rho vector of rho_1 to rho_k for our model
rhok <- function(k) {
  phi = -0.8
  theta = c(1.88, -0.98)
  gamma0 = (1/(1-phi^2))*(1-2*phi*theta[1]-2*phi*theta[2]*(phi-theta[1])+(theta[1])^2+(theta[2])^2)
  rho = phi - (theta[1] + phi * theta[2] - theta[1] * theta[2]) * 1 /gamma0
  
  if (k == 1){return (rho)}
  rho[2] = phi * rho[1] - theta[2]/gamma0
  if (k == 2){return (rho)}
  for (j in 3:k) {
    rho[j] = phi * rho[j-1]
  }
  return (rho)
}


#NB: rho zero not included in the vector, this is for k lags
#k=30
#rhovector = rhok(k)
#pacf for same number of lags as the rhovec has
#mpacf = rhoToPACF(rhovector)
#durbin = rhoToPACF(rhovector, regCoefs=TRUE)
#weights = durbin$weights
#variance = durbin$variance
#plot(c(1:k), mpacf)

#Compute the actual forecast:
load(url("https://www.math.ntnu.no/~jarlet/tidsrekker/zforecast.Rdata"))
j=length(z)
rhovector = rhok(j)
#pacf for same number of lags as the rhovec has
mpacf = rhoToPACF(rhovector)
durbin = rhoToPACF(rhovector, regCoefs=TRUE)
#weights = durbin$weights
#variance = durbin$variance
jj=1:j
forecast = sum(z[j+1-jj]*durbin$weights[jj])
#forecast error variance is
variance = durbin$variance #approx 7.69, this seems excessively high
altVariance = durbin$altVar #APPROX 1.077, this seems more corect, but how/why different?
#try something else:

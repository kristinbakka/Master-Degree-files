
acf2pacf <- function(rhoVec,gamma0)  {
  nextPhiVec = rep(NA,length(rhoVec))
  pacfVec = rep(NA, length(rhoVec))
  pacfVec[1] = rhoVec[1]
  phiVec = pacfVec
  vk = gamma0*(1-(pacfVec[1])^2)
  for (k in 1:(length(rhoVec)-1)){
    sum1=0
    sum2=0
    for (j in 1:k){ #kloop
      sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
      sum2 = sum2 + phiVec[j]*rhoVec[j]
    }
    pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    nextPhiVec[k+1]=pacfVec[k+1]
    vk[k+1] = vk[k]*(1-(pacfVec[k+1])^2)
    for (j in 1:k){ #For j in 1:k
      nextPhiVec[j] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
    }
    phiVec = nextPhiVec
  }
  return(list("weights"=phiVec,"variance"=vk, "pacf"=pacfVec))
}


#Compute initial parameter values by ML estimation
#1.1 compute sample acf \rho
#1.2 compute sample corr \gamma_0
#2 obtain \phi_1^ĥat and \phi_2^hat (DL)
# \sigma^2 = \gamma_0*(1 - phi_1^hat*rho_1^hat  -  phi_2^hat*rho_2^hat)

#0: something to test on:
set.seed(500)
myn=200
myModel=arima.sim(list(order = c(2,0,0), ar = c(0.8897, -0.4858)), n = myn)
ts.plot(myModel)

#1.1 compute sample gamma_0
#myMean = sum(myModel)/myn
myMean=0
myGamma0 = (1/myn)*sum((myModel-myMean)^2) #there are lots of ways to estimate it

#1.2 compute sample acf
#the sample acf cuts off for an AR(2) process after lag 2, this is why this makes sense at all :D)
rhos = c(sum((myModel[1:(myn-1)]-myMean)*(myModel[2:(myn)]-myMean))/(myn*myGamma0),
  sum((myModel[1:(myn-2)]-myMean)*(myModel[3:(myn)]-myMean))/(myn*myGamma0) )
  
#2 obtain \phi_1^ĥat and \phi_2^hat and sima_a^2
phis = acf2pacf(rhos,myGamma0)
sigmaa2 = myGamma0*(1-sum(phis$weights*rhos))
call=0
lnL <- function(param,z){
#  print("-------------------------------------------------------")
  
  phi1 <- unlist(param[1])
  if (phi1< -1.9){
    phi1=-1.9
  }
  if (phi1> 1.9){
    phi1=1.9
  }
  phi2 <- unlist(param[2])
  if (phi2 < -0.9){
    phi1=-0.9
  }
  if (phi1>0.9){
    phi1=0.9
  }
  sigma_a2 <- unlist(param[3])
  sigma_a2 = sign(sigma_a2)*sigma_a2
  if (sigma_a2<0.001){
    print(c("sigma_a2",sigma_a2))
  }
  n <- length(z)
  t <- 3:n
  #how come they are sometimes negative? This should not happen!
  gamma0 = sigma_a2*(1-phi2)/((1+phi2)*(1+phi1-phi2)*(1-phi1-phi2))
#  print(c("This is gamma0",gamma0))
  gamma0 = sign(gamma0)*gamma0
  phi11 = (1-phi1-phi2)/(1-phi2)
  v1 = gamma0*phi11
#  print(c("v1 ",v1, "gamma0", gamma0, "phi11", phi11, "phi1", phi1, "phi2", phi2))
  v1 = sign(v1)*v1
  call = call+1
  
  #S <-  sum(z[3:n]-phi1*z[2:(n-1)]-phi2*z[1:(n)])
  S <-  sum(z[t]-phi1*z[t-1]-phi2*z[t-2])
  #print(S)
  tmp <- -n*log(2 *pi)/2 -log(gamma0)/2 - log(v1)/2 -(n-2)*log(sigma_a2)/2 - 
    z[1]^2/(2*gamma0) - (z[2]-phi11*z[1])^2/(2*v1) -(2*sigma_a2)^(-(n-2)) *S
#  print(tmp)
  b=5
  return(-tmp)
}

phi1=1.41946487040573
phi2=-0.468211958715981
sigma_a2=9.90837298521211/((1-phi2)/((1+phi2)*(1+phi1-phi2)*(1-phi1-phi2)))
#param=list("nb1"=1.41946487040573,"nb2"=-0.468211958715981, sigma_a2)
param=list(1.41946487040573,-0.468211958715981, sigma_a2)
z=myModel
#a=lnL(param=c(phis$weights, sigmaa2),z=myModel)
a=lnL(param=c(1.41946487040573,-0.468211958715981, sigma_a2),z=z)

#Try to constrain it to only stationary values:
#  fit <- optim(c(phis$weights, sigmaa2),lnL,z=myModel,method = "L-BFGS-B",lower = c(-1.9,-0.999,0.01), upper =c(1.9,0.999,Inf),hessian=FALSE)
fit <- optim(c(phis$weights, sigmaa2),lnL,z=myModel,hessian=FALSE)

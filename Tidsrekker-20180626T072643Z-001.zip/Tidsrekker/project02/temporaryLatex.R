
and every observation after that has expectation
\begin{align*}
E[Z_t|Z_{t-1}=z_{t-1},Z_{t-2}=z_{t-2}] &= E[\phi_1 z_{t-1}] + E[\phi_2 z_{t-2}] + E[a_1] \\
E[Z_t|Z_{t-1},Z_{t-2}] &=0 \;.
\end{align*}
and variance
\begin{align*}
E[Z_t^2|Z_{t-1},Z_{t-2}] &= E[\phi_1 Z_{t-1} Z_{t}] + E[\phi_2 Z_{t-2} Z_{t}] + E[a_1 Z_{t}] \\
E[Z_t^2|Z_{t-1},Z_{t-2}] &= \phi_1 \gamma_1 + \phi_2 \gamma_2 + \sigma_a^2 \;.
\end{align*}


acf2pacf <- function(rhoVec,gamma0)  {
  nextPhiVec = rep(NA,length(rhoVec))
  pacfVec = rep(NA, length(rhoVec))
  pacfVec[1] = rhoVec[1]
  phiVec = pacfVec
  vk = gamma0*(1-(pacfVec[1])^2)
  for (k in 1:(length(rhoVec)-1)){
    sum1=0
    sum2=0
    for (j in 1:k){ #kloop
      sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
      sum2 = sum2 + phiVec[j]*rhoVec[j]
    }
    pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    nextPhiVec[k+1]=pacfVec[k+1]
    vk[k+1] = vk[k]*(1-(pacfVec[k+1])^2)
    for (j in 1:k){ #For j in 1:k
      nextPhiVec[j] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
    }
    phiVec = nextPhiVec
  }
  return(list("weights"=phiVec,"variance"=vk, "pacf"=pacfVec))
}

lnL <- function(param,z){
  phi1 <- unlist(param[1])
  phi2 <- unlist(param[2])
  sigma_a2 <- unlist(param[3])
  n <- length(z)
  t <- 3:n
  gamma0= sigma_a2/(1-phi1^2/(1-phi2)- phi1^2*phi2/(1-phi2)-phi2^2)
  phi11 = phi1/(1-phi2)
  v1 = gamma0*(1-phi11^2)
  S <-  sum((z[t]-phi1*z[t-1]-phi2*z[t-2])^2)
  tmp <- -n*log(2 *pi)/2 -log(gamma0)/2 - log(v1)/2 -(n-2)*log(sigma_a2)/2 - 
    z[1]^2/(2*gamma0) - (z[2]-phi11*z[1])^2/(2*v1) -(2*sigma_a2)^(-1) *S
  return(-tmp)
}

exactL <-function(n,myModel){
#1 compute sample gamma_0
myMean=0
gamma0 = (1/n)*sum((myModel-myMean)^2) #there are lots of ways to estimate it

#2 compute sample acf
rhos = c(sum((myModel[1:(n-1)]-myMean)*(myModel[2:(n)]-myMean))/(n*gamma0),
  sum((myModel[1:(n-2)]-myMean)*(myModel[3:(n)]-myMean))/(n*gamma0) )
  
#2 obtain \phi_1^hat and \phi_2^hat and sima_a^2
phis = acf2pacf(rhos,gamma0)
sigmaa2 = gamma0*(1-sum(phis$weights*rhos))


#fit <- optim(c(phis$weights, sigmaa2),lnL,z=myModel,hessian=TRUE)
fit <- optim(c(0.8897, -0.4858, 1),lnL,z=myModel,hessian=TRUE)

return(c(phis$weights, sigmaa2, parametersExact=fit$par))
}


par(mfrow=c(3,1))
yInit=0
yExact =0
y2Init=0
y2Exact =0
sigmaInit = 1
sigmaExact= 1

n=20
a1=0.8897
a2=-0.4858
sigma=1.37
for (i in 1:100){
  myModel=arima.sim(list(order = c(2,0,0), ar = c(a1, a2)), n = n, sd = sigma)
  #ts.plot(myModel)
  atry = exactL(n = n,myModel)
  yInit[i] = atry[1]
  yExact[i] = atry[3+1]
  y2Init[i] = atry[2]
  y2Exact[i] = atry[3+2]
  sigmaInit[i] = atry[3]
  sigmaExact[i] = atry[3+3]
}
plot(yInit, col='red',main="First parameter",xlab="Run", ylab="estimate")
points(yExact, col='blue',pch="+")
abline(a=a1, b=0)
abline(a= a1+2*(var(yExact))^(1/2), b=0, col="blue")
abline(a=a1-2*(var(yExact))^(1/2), b=0, col="blue")
abline(a= a1+2*(var(yInit))^(1/2), b=0, col="red")
abline(a=a1-2*(var(yInit))^(1/2), b=0, col="red")

plot(y2Init, col='red',main="Second parameter",xlab="Run", ylab="estimate")
points(y2Exact, col='blue',pch="+")
abline(a=a2, b=0)
abline(a= a2+2*(var(y2Exact))^(1/2), b=0, col="blue")
abline(a=a2-2*(var(y2Exact))^(1/2), b=0, col="blue")

plot(sigmaInit, col='red',main="Variance",xlab="Run", ylab="estimate")
points(sigmaExact, col='blue',pch="+")
abline(a=sigma^2, b=0)
abline(a=sigma^2+2*(var(sigmaExact))^(1/2), b=0, col="blue")
abline(a=sigma^2-2*(var(sigmaExact))^(1/2), b=0, col="blue")


max(yExact)-mean(yExact)
2*(var(yExact))^(1/2)




#fit2 <- lm(myModel[3:n] ~ myModel[2:(n-1)] + myModel[1:(n-2)] )
#anova()

#qqnorm(yExact, main = "Normal Q-Q Plot Exact",
#       xlab = "Theoretical Quantiles", ylab = "Sample Quantiles",
#       plot.it = TRUE, datax = FALSE)
#qqnorm(yInit, main = "Normal Q-Q Plot Initial",
#       xlab = "Theoretical Quantiles", ylab = "Sample Quantiles",
#       plot.it = TRUE, datax = FALSE)
#var(yInit)
#var(yExact)




acf2pacf <- function(rhoVec,gamma0)  {
  nextPhiVec = rep(NA,length(rhoVec))
  pacfVec = rep(NA, length(rhoVec))
  pacfVec[1] = rhoVec[1]
  phiVec = pacfVec
  vk = gamma0*(1-(pacfVec[1])^2)
  for (k in 1:(length(rhoVec)-1)){
    sum1=0
    sum2=0
    for (j in 1:k){ #kloop
      sum1 = sum1 + phiVec[j]*rhoVec[k+1-j]
      sum2 = sum2 + phiVec[j]*rhoVec[j]
    }
    pacfVec[k+1]=(rhoVec[k+1]-sum1)/(1-sum2)
    nextPhiVec[k+1]=pacfVec[k+1]
    vk[k+1] = vk[k]*(1-(pacfVec[k+1])^2)
    for (j in 1:k){ #For j in 1:k
      nextPhiVec[j] = phiVec[j]-pacfVec[k+1]*phiVec[k+1-j]
    }
    phiVec = nextPhiVec
  }
  return(list("weights"=phiVec,"variance"=vk, "pacf"=pacfVec))
}


#Compute initial parameter values by ML estimation
#1.1 compute sample acf \rho
#1.2 compute sample corr \gamma_0
#2 obtain \phi_1^ĥat and \phi_2^hat (DL)
# \sigma^2 = \gamma_0*(1 - phi_1^hat*rho_1^hat  -  phi_2^hat*rho_2^hat)

#0: something to test on:
#set.seed(500)
n=200
myModel=arima.sim(list(order = c(2,0,0), ar = c(0.8897, -0.4858)), n = n)
ts.plot(myModel)

#1.1 compute sample gamma_0
#myMean = sum(myModel)/n
myMean=0
gamma0 = (1/n)*sum((myModel-myMean)^2) #there are lots of ways to estimate it

#1.2 compute sample acf
#the sample acf cuts off for an AR(2) process after lag 2, this is why this makes sense at all :D)
rhos = c(sum((myModel[1:(n-1)]-myMean)*(myModel[2:(n)]-myMean))/(n*gamma0),
  sum((myModel[1:(n-2)]-myMean)*(myModel[3:(n)]-myMean))/(n*gamma0) )
  
#2 obtain \phi_1^ĥat and \phi_2^hat and sima_a^2
phis = acf2pacf(rhos,gamma0)
sigmaa2 = gamma0*(1-sum(phis$weights*rhos))

lnL <- function(param,z){
  phi1 <- unlist(param[1])
  phi2 <- unlist(param[2])
  sigma_a2 <- unlist(param[3])
  n <- length(z)
  t <- 3:n
  gamma0= sigma_a2/(1-phi1^2/(1-phi2)- phi1^2*phi2/(1-phi2)-phi2^2)
  phi11 = (1-phi1-phi2)/(1-phi2)
  v1 = gamma0*phi11
  S <-  sum((z[t]-phi1*z[t-1]-phi2*z[t-2])^2)
  tmp <- -n*log(2 *pi)/2 -log(gamma0)/2 - log(v1)/2 -(n-2)*log(sigma_a2)/2 - 
    z[1]^2/(2*gamma0) - (z[2]-phi11*z[1])^2/(2*v1) -(2*sigma_a2)^(-1) *S
  return(-tmp)
}

fit <- optim(c(phis$weights, sigmaa2),lnL,z=myModel,hessian=TRUE)

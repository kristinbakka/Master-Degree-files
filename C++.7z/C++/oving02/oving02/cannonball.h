//Hva skulle jeg skrevet �verst for � passe p� at den blir inkludert max 1 gang?

// Akselerasjonen i y-retning:
double acclY();

// Y-hastigheten:
double velY(double startfartY, double tid);
//Yhastigheten vha. integrasjon:
double velIntY(double startfartY, double tid);

// POSISJON
//x med formel
double posX(double startfartX, double tid);
//x med integrasjon
double posIntX(double startfartX, double tid);
//y med formel
double posY(double startfartY, double tid);
//y med integrasjon
double posIntY(double startfartY, double tid);

//tar inn tid i sekunder og printer timer, minutter, sekunder. :)
void printTime(double sek);
double flightTime(double startfartY);

void getUserInput(double *theta, double *absVelocity);
double getVelocityX(double theta, double absVelocity);
double getVelocityY(double theta, double absVelocity);
void getVelocityVector(double theta, double absVelocity, double *velocityX, double *velocityY);

double getDistanceTraveled(double velocityX, double velocityY);
double optimalAngleForMaxDistance(double absVelocity);

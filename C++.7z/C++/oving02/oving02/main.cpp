#include <iostream>
using namespace std;
#include <cmath>
#include"cannonball.h"
#include <iomanip>

int main(){
double aY = acclY();
cout << "Bestem deg for en startfart i x-retning: ";

double startfart = 50;
cin >> startfart;
double startfarty = 25;

double velyT0 = velY(startfarty, 0);
double velyT2 = velY(startfarty, 2.5);
double velyT5 = velY(startfarty, 5.0);

double posxT0  = posX(startfart, 0);
double posxT2 = posX(startfart, 2.5);
double posxT5 = posX(startfart, 5.0);

double posyT0 = posY(startfarty, 0);
double posyT2 = posY(startfarty, 2.5);
double posyT5 = posY(startfarty, 5.0);

cout << "\tT = 0\tT = 2.5\tT = 5.0\n";
cout << "acclX \t0\t0\t0\n";
cout << "acclY\t"<< aY        << "\t" << aY        << "\t" << aY        << endl;
cout << "velX\t" << startfart << "\t" << startfart << "\t" << startfart << endl;
cout << "velY\t" << velyT0    << "\t" << velyT2    << "\t" << velyT5    << endl;
cout << "posX\t" << posxT0    << "\t" << posxT2    << "\t" << posxT5    << endl;
cout << "posY\t" << posyT0    << "\t" << posyT2    << "\t" << posyT5    << endl;



	system("pause");
	return 0;
}
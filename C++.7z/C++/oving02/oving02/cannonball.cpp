#include <iostream>
using namespace std;
#include <cmath>
#include"cannonball.h"
#include <iomanip>

double acclY(){
	double a = -9.81;
	int ans = 1;
	cout << "\nHvis akselerasjonen i positiv y-retning er -9.81, trykk 1, hvis ikke trykk 2. " ;
	cin >> ans;

	if (ans == 1){
		return a;
	}

	cout << "Skriv inn akselerasjonen i positiv y-retning: ";
		cin >> a;
	
	if (a < 0){
		return a;
	}

	cout << "Akselerasjonen er positiv i positiv x-retning. Er dette meningen?\nDu har skrevet at akselerasjonen i positiv y-retning er " << a ;
	cout << ", skriv inn akselerasjonen i positiv y-retning: ";
		cin >> a;
		cout << endl;
		return a;
}

double velY(double startfartY, double tid){
	double ans = startfartY + acclY()*tid ;
	return ans;
}

double velIntY(double startfartY, double tid){
	double dt = tid/500; //Kan be bruker om � gi dette inn, men det er slitsomt for bruker.
	double	fartY = startfartY ;
	double aY = acclY();
	
	for(double t = 0; t<=tid; t += dt) {
	fartY = fartY + aY*dt ;
	}
return fartY;
}

double posX(double startfartX, double tid){
	double aX = 0.0; //hvis det ikke er vind.
	double posisjon = 0.0 + startfartX * tid +0.5 * aX * tid *tid ;
	return posisjon;
}

double posY(double startfartY, double tid){
	double startPosisjon = 0;
	double aY = acclY();
	double posisjon = startPosisjon + startfartY * tid + 0.5 * aY *tid*tid ;
return posisjon;
}

double posIntY(double startfartY, double tid){
	double startPosisjon = 0;
	double posisjon = startPosisjon;
	double currentVelocity = startfartY;
	double dt = tid/500; //Kan be bruker om � gi dette inn, men det er slitsomt for bruker.
	
	for(double t = 0; t<=tid; t += dt) {
		posisjon += currentVelocity*dt;
		currentVelocity = velY(startfartY, t+dt);
	}
	return posisjon;
}

double posIntX(double startfartX, double tid){
	double startPosisjon = 0;
	double posisjon = startPosisjon;
	double dt = tid/500; //Kan be bruker om � gi dette inn, men det er slitsomt for bruker.
	
	for(double t = 0; t<=tid; t += dt) {
		posisjon += startfartX*dt;
	}
	return posisjon;
}

void printTime(double sek){
	int timer = 0;
	int minutter = 0;
	double sekunder = 0;
	int intsek = sek; //For � kunne bruke %
	
	timer = (intsek - intsek %3600)/3600 ;
	minutter = (intsek-60*timer);
	minutter = (minutter - minutter%60)/3600;
	sekunder = sek - timer*3600 - minutter*60 ;

	cout << setprecision(2) << fixed ;
	cout << sek << " sekunder tilsvarer " << timer << " timer, " << minutter << " minutter, og " << sekunder << " sekunder.\n";
}

double flightTime(double startfartY){
	//Der akselerasjonen er negativ vil gjestanden ha n�dd utskytningsh�yden n�r hastigheten er motsatt rettet og like stor som starthastigheten. Evt. er tiden 2x det det tar � f� null hastighet.
	//funksjonen vil late som om akselerasjonen er motsatt rettet av kasteretningen:
	double a = acclY();
	return 2*startfartY/(sqrt(a*a)) ;
}

void getUserInput(double *theta, double *absVelocity){
*theta = -1;
*absVelocity = -1;

	while (*theta < 0 || *theta >1.15707){
	cout << "What is the angle between the startdirection and the ground in radians (must be between 0 and 1.5707 = pi/2)? \n";
	cin >> *theta;
	}

	while (*absVelocity < 0 ){
	cout << "What is the size of the initial velocity? \n";
	cin >> *absVelocity;
	}
}

double getVelocityX(double theta, double absVelocity){
	return (cos(theta)*absVelocity);
}
double getVelocityY(double theta, double absVelocity){
	return (sin(theta)*absVelocity);
}

void getVelocityVector(double theta, double absVelocity, double *velocityX, double *velocityY){
	*velocityX = getVelocityX(theta, absVelocity);
	*velocityY = getVelocityY(theta, absVelocity);
}

double getDistanceTraveled(double velocityX, double velocityY){
	return( posX( velocityX, flightTime(velocityY) )  );
}

double optimalAngleForMaxDistance(double absVelocity){
	//en lur metode hadde v�rt � gjette midtverdien (theta = pi/4) og f�rst 
	//lete eks i + retning, hvis svaret er st�rre blir dette den nye nullverdien 
	//og du leter i +retning. N�r man f�r et mindre svar leter man i -retning, 
	//og samme gjentas for +retning. Siden vi vet hva svaret er blir gjetningen 
	//v�r for god, og det vil ikke skje noe, s� vi gj�r dette istedenfor: 

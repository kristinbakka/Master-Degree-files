#include <iostream>
#include <cmath> //pow(i,2) = i^2
#include <math.h> //mod(
#include <vector>


using namespace std;

//a) Fibonaccirekker:
int fibonacci(int n) {
	int a = 0;
	int b = 1;
	cout << "Fibonacci numbers: " ;
	for (int x =0; x < n; x++){
		int temp = b;
		b = a + b;
		a = temp;
		cout << x << " : " << b << endl;
	}
	cout << "----\n" ;
		return b;
}

//OPPGAVE 2B - Trekanttall
void triangleNumbersBelow(int n){
	int acc = 1;
	int num = 2;
	cout << "Triangle numbers below " << n << " : " ;
	while (acc + num < n){
		acc += num ; 
		num++ ;
		cout << acc << " " ;
	}
	cout << endl ;
}

bool isTriangleNumber(int number){
	int acc = 1 ;
	while (number > 0){
		number = number - acc ;
		acc++ ;
	}
	if(number == 0){
		return true;
	}
	else{
		return false;
	}
}

//OPPGAVE 2C - Sum av kvadrerte tall
void squareNumberSum( int n){
	int totalsum = 0;
	for (int i=1 ; i<=n ; i++){ //Det st�r riktignok i informasjonen at vi skal 
		//la "i" l�pe fra 0 til ekte mindre enn n, men da blir den f�rste totalsummen 1 lavere.
		totalsum = totalsum + i*i ;
		cout << pow(i,2.0) ; //Jeg pr�ver meg p� � opph�ye p� denne m�ten ved � inkludere cmath. :)
	}
}

//OPPGAVE 2D - St�rste av to tall
int maxOfTwo( int a, int b){
	if (a > b){
		cout << "A is greater than B" << endl;
		return a;
	}
	else{
		cout << "B is greater than or equal to A" << endl;
		return b;	
	}
}

//OPPGAVE 2E - Primtall 1
bool isPrime(int n){
	bool primeness = true;
	for (int i =2 ; i <= (n-1); i++){
		int s = n;
		while(s >= i){
			s = n-i;
		}
		if (s == 0){
			return false;
		}
	}
	return primeness;
}

//OPPGAVE 2F - Primtall 2
int naivePrimeNumberSearch(int n){
	for(int number =2 ; number<=(n-1) ; number++){
		if (isPrime(number) == true){
			cout << n << " is a prime number. \n" ;
		}
	}
return 0;
}

//OPPGAVE 2G - St�rste fellesnevner
int mod(int n, int divisor){
	int rest = n;
		while(rest >= divisor){
			rest = n-divisor;
		}
		return rest;
}


int findGreatestDivisor(int n){
	for( int divisor = (n-1) ; divisor <=0 ; divisor = divisor -1){
		if (mod(n , divisor) == 0){
			return divisor;
		}
	}

}

//OPPGAVE 2H - Telling med lister
int compareListOfNumbers(int l[], int length){ //hvilken type skal l v�re n�r l er vektor?
	int r[3] = {0 , 0, 0}; //dette skal visst v�re hvordan man lager vektor. Hvordan lager man tabell? :)
	for(int i = 0; i< length ; i++){ //Hva gj�r jeg med length?
		if (l[i]<0){
			r[0]++; 
		}
		else{
			if (l[i]==0) { //dette er elseif
				r[1]++ ;
			}
			else{
				r[2]++ ;
			}
		}
	}

	cout << r[0] << " numbers were below zero \n" ;
	cout << r[1] << " numbers were zero \n" ;
	cout << r[2] << " numbers were above zero \n" ;
return 0;
}



		int main() {
			triangleNumbersBelow(15);


			int hei[10] = {1, 3, 4, 2, 1, 4, 2, 3, 1, 2};
			compareListOfNumbers(hei, 10);
			
			system("pause");
	return 0 ;
}
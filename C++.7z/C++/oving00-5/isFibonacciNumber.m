function [ trueOrFalse ] = isFibonacciNumber( n )
%Oversetter C++ til matlab. �ving 0.5 oppg 1 a)
% Funksjonen finner ut om n er et fibonaccitall

a = 0;
b = 1;
while b < n
    temp = b ;
    b = a + b ;
    a = temp ;

end

if b == n
    trueOrFalse = true;
else
    trueOrFalse = false;
end

end


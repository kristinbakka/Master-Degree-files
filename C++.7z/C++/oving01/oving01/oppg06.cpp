#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std ;
#include"funksjoner.h";
#include"oppg06.h";

//Jeg har probleer med pc'en s� den klarer ikke � kompilere. Derfor lager jeg resten av �vingen i denne filen. :)
;
void calculateLoanPayments(){

double	tot = getAndReturnDouble();
double gjeld = tot;
double	rente = getAndReturnDouble();
double innbetalt = 0;
int antall_avdrag = 10;
	cout << setprecision(2) << fixed << endl;
	cout << "Aar \tResterende \tRente \t\tAvdrag \t\tTotal innbetaling";
	for (int i=0; i< antall_avdrag ; i++){
		cout << i+1 << "\t" << gjeld << "\t" << rente*gjeld/100 << "\t" << tot/antall_avdrag << "\t" << rente*gjeld/100+tot/antall_avdrag << endl;
	innbetalt += rente*gjeld/100+tot/antall_avdrag;	
	}
	cout << "Du har betalt inn " << innbetalt << "til banken totalt, dvs " << tot - innbetalt << " mer enn du l�nte. \n" ;
}
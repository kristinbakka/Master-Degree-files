#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std ;
#include"funksjoner.h";
#include"oppg06.h";
;
int main(){
	int i = 1;
	do{

	cout << "Veldg funksjon: " << endl;
	cout << "0) Avslutt" << endl;
	cout << "1) Summer to tall" << endl;
	cout << "2) Summer flere tall" << endl;
	cout << "3) Konverter NOK til EURO" << endl;
	cout << "4) Konverter sekunder tim timer, minutter og sekunder" << endl;
	cout << "5) Hva blir matens totalkostnad?" << endl;
	cout << "6) Er tallet partall eller oddetall?" << endl;
	cout << "7) Hvilket av disse tallene er st�rst?" << endl;
	cout << "8) Andregradsligning." << endl;
	cout << "9) Betale gjeld." << endl;
	cout << "\nAngi valg (0-9): " ;
	int valg = 0;
	cin >> valg ;
	switch (valg){
		case 0:
			break;
		case 1:
			getAndPrintSum();
			break;
		case 2:
			getAndPrintMoreSums(5);
			break;
		case 3:
			NOKtoEUR();
			break;
		case 4:
			sekTilTid();
			break;
		case 5:
			mealPrice();
			break;
		case 6:
			oddeEllerLike();
			break;
		case 7:
			greatestNumber();
			break;
		case 8:
			solveAndPrintRoots();
			break;
		case 9:
			calculateLoanPayments();
			break;
		}
	cout << "\n\nSkriv 1 for aa kjore en gang til: ";
    cin >> i;

	}while(i == 1);


	
return 0 ;
}
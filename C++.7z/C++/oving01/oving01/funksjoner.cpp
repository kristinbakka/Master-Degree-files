# include <iostream>
#include <iomanip>
#include <cmath>
using namespace std ;
#include"funksjoner.h";

//Oppgave 01 a)
void getAndPrintInteger(){
	cout << "Skriv inn et tall: " ;
	int tall = 0;
	cin >> tall;
	cout << "Du skrev: " << tall << endl;
}

//Oppgave 01 b)
int getAndReturnInteger(){
	cout << "Skriv inn et tall: " ;
	int tall = 0;
	cin >> tall;
	return tall;
}

//Oppgave 01 c)
//Funksjon 2 har returtype int for integer(heltall), og det er fordi den skal gi tilbake et heltall.
//Funksjon 1 har returtype void, det er fordi den ikke skal gi ut noe.
//Det � skrive til skjerm har ingen ting � gj�re med om funksjonen returnerer noe eller ikke.
//Void betyr tomrom, og er returtypen n�r man ikke returnerer noe.
//Forskjellen p� returtype Void og int er at man gir noe ut med int, o gat det er et heltall.

//Oppgave 01 d)

void getAndPrintSum(){
	int a = 0;
	int b = 0;
	a = getAndReturnInteger();
	b = getAndReturnInteger();
	cout << "Summen er: " << a + b << endl;
}

//Oppgave 01 e)
//Jeg valgte � bruke funksjon 2 fordi jeg hadde lyst til � bruke tallet videre til noe annet.
//Det kunne jeg ikke gjort med funksjon 1, for da ville jeg bare skrevet til skjerm.
//Hvordan skal man skvise fem setninge rut av dette?


//OPPGAVE 2 a)
void getAndPrintMoreSums(int number){
	//Number is the number of items to be printed. When sum is 0 summation will stop. Number must be bigger than 0
	int sum = 0;
	int i = 0;
do { 
i++;
sum += getAndReturnInteger();
}
while(sum!=0 || i < number) ;
cout << "The sum of the " << number <<" sums is: " << sum << endl;
}

//Oppgave 02 b)
//Et alternativ er � vente p� at summen blir 0 f�r du avslutter.
//Da er det best med while elelr do while.
//Det er fordi du ikke vet hvor mange ganger du vil at l�kken skal kj�re.
//Fordelen med do-while er at de f�r gitt inn et tall.
//Det er helt greit � bruke do-while ogs�.
//N�r du vet at du skal summerer akkurat n tall er det lettest med ifl�kke.
//Den er tilpasset kjent antall iterasjoner. :)


//Oppgave 02 c)
double getAndReturnDouble(){
	cout << "Skriv inn et desimaltall: " ;
	double tall = 0;
	cin >> tall;
	return tall;
}

//Oppgave 02 d)
//#include <iomanip>
void NOKtoEUR(){
	double NOK = 0;
	cout << setprecision(2) << fixed;
	do{ 
		NOK = getAndReturnDouble();
	}while( NOK < 0 ) ;
		//1euro = 7.84 NOK
		double EUR = NOK/7.84 ;
	cout << NOK << " NOK tilsvarer "<< EUR << " EUR. \n";
}

//OPPGAVE 02 e)
//Burde ikke bruke den som gir meg heltall, fordi jeg skal kunne f� inn desimaltall.
//Det st�r spesifikt i oppgaveteksten at det skal v�re slik.
//Returtypen til funskjonen er void.
//Det er fordi fnskjeonen ikke returnerer noe.
//Istedenfor skriver den til skjerm. :)

//Oppgave 02 g)
void gangetabell (int hoyde, int bredde){
	int rad = 0;
	int kol = 0;
	//Gangetabell etter modell fra barneskolen, starter p� 0.
for (rad = 0 ; rad < hoyde ; rad++){
	for (kol = 0 ; kol <bredde ; kol++){
		cout << rad * kol << "\t" ;
	}
	cout << endl;
}
}

//Overse tittelen p� filen, dette er ogs� oppgave 3. :)

//OPPGAVE 3a)
void sekTilTid(){
	int sekunder=0; int minutter=0; int timer=0; int sek = 0;
	cout << "Skriv inn antall hele sekunder: " ;
	cin >> sek;
	sekunder = sek%60;
	minutter = sek%3600-sekunder;
	timer = (sek - sekunder - minutter)/3600 ;
	minutter = minutter/60;
	cout << timer<<" timer, "<<minutter << " minutter, "<< sekunder << " sekunder \n" ;
}

//OPPGAVE 3b)
void mealPrice(){
	double basic = 0.00; double mva = 0.0875; double tips = 0.18; double sum = 0.00 ;

	cout << "Hvor mange dollar skulle maten kostet: ";
	cin >> basic ;

	mva = mva*basic;
	tips = (mva+basic)*tips;
	sum = basic + mva + tips;
	cout << setprecision(2) << fixed;
	
	cout << "Maten kostet orginalt: \t"<<basic<<" dollar. \nMoms blir: \t\t"<<mva <<" dollar \nTips blir: \t\t" << tips <<" dollar. \n Tilsammen blir det " << sum << " dollar. \n";
}


//OPPGAVE 4a)
void oddeEllerLike(){
	if (getAndReturnInteger()%2 == 0){
		cout << "Tallet er et partall. \n";
	}
	else{
		cout << "Tallet er et oddetall";
	}
}

//OPPGAVE 4b)
void greatestNumber(){
	double a = getAndReturnDouble();
	double b = getAndReturnDouble();
	if (a > b){
	cout << a << " er storst.\n";
	}
	else{
	cout << b << " er storst.\n";
	}
}

//OPPGAVE 4c)
//En funksjon som tarr inn to tall blir deklarert med at den tar inn to parametere.
//Funksjonen m� mats av datamaskinen med to argumenter n�r den skal kj�res.
//N�r funskjonen skal la deg skrive inn to tall, betyr det at funksjonene ikke trenger at
//de tallene skal bli gitt inn som argumenter, for funksjonen klarer � finne dem p� egenh�nd;
//nemlig med � sp�rre brukeren om verdien til tallene. :)

double internalSum(double a, double b, double c){
	return (pow(b,2)-4*a*c);
}

double positiveSqrt(double x){
	if (x < 0){
		return (-1);
	}
	return sqrt(x);
}

double polyRoot(double a, double b, double c){
	return (positiveSqrt  ( internalSum(a,b,c) )  );
}

void abcFormula(double a, double b, double c){
int antsvar = 2;
double d = positiveSqrt(internalSum(a,b,c));

if (d == -1) {antsvar = 0; 	cout <<"no real solutions \n" ; }
	else{
		if (d == 0)  {antsvar = 1; cout <<"two equal real solutions x = " << (-b/(2*a));
		}
			else {
			cout << "two real solutions \tx_1 = " << (-b+d)/(2*a) << " and x_2 = " << (-b-d)/(2*a);
			}
		}
}

void solveAndPrintRoots(){
	double a = getAndReturnDouble();
	double b = getAndReturnDouble();
	double c = getAndReturnDouble();
	cout << "\nTrying to solve the equation  \n\t0  = " << a << " x^2 +  " <<b<<" x +  "<< c << "\n we get ";
		abcFormula(a, b, c);
}






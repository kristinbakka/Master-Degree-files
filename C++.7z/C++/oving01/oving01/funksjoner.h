//Hva skulle jeg skrevet �verst for � passe p� at den blir inkludert max 1 gang?
void getAndPrintInteger();

int getAndReturnInteger();

void getAndPrintSum();

void getAndPrintMoreSums(int number);

double getAndReturnDouble();

void NOKtoEUR();

void gangetabell (int hoyde, int bredde);

void sekTilTid();

void mealPrice();

void oddeEllerLike();

void greatestNumber();

double internalSum(double a, double b, double c);

double positiveSqrt(double x);

double polyRoot(double a, double b, double c);

void abcFormula(double a, double b, double c);

void solveAndPrintRoots();


#include <iostream>
// Dette er et helt enkelt program som du kan kopiere og bruke i
// denne oevingen.
using namespace std;
int main(){
cout << "Hello World!";
return 0;
}